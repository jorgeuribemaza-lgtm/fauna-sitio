> **V13.8 · 2026-11-03.** **Todo el sitio en inglés** en `en/` (32 páginas; `panel.html` queda solo en español por ser privado), con selector ES/EN en cada encabezado, `hreflang` en las dos versiones y una franja que ofrece el inglés a quien llega con el navegador en otro idioma. `sitio.js` y `lfi-core.js` toman el idioma de `<html lang>`; las trivias de muestra en inglés salen de las traducciones oficiales de `data/cartas.json`; contacto en inglés en `data/contacto.en.json` con su QR (`assets/qr-sitio-en.png`). Los PDF (cuentos, reglamento, tablero, invitación, paquete docente) siguen en español y así se indica en inglés. **Calidad original restaurada**: 10 cuentos, reglamento y folleto, tablero para imprimir (la versión comprimida tenía bloques negros) y título de la consola; cartel de Wanha' también en versión para imprenta. **Los quince en el portal**: ÁMBAR, BALEY, CIMA, INIA y CRUM estrenan ficha (español e inglés), entran a «Los quince», al registro `data/sitio.json`, a `CODES` y a los selectores de Primera partida y Paquete de guardián; sus 32 cartas ENCUENTRO con opciones A/B ganan `Efecto__EN`. **Publicación desde GitHub**: repositorio `jorgeuribemaza-lgtm/fauna-sitio`, flujo `.github/workflows/publicar.yml` que une `sitio-parte-*.zip` y publica en el proyecto `betafaunaguardianes` de Cloudflare Pages. `contentRevision v13-8-ingles`.
>
> **V13.7 · 2026-11-03.** Los cinco Guardianes de Wanha' ya tienen nombre, resultado del concurso de nombres: **RIZELA** (MGL, mangle rojo), **XIKNAL** (ESP, espátula rosada), **CENTOR** (ROB, róbalo), **BRAMOR** (SAR, saraguato negro) y **MELITA** (MEL, abeja melipona). Los códigos de carta no cambian (RET-SAR-02 y demás siguen igual en el directorio de aliados y el gestor). Se aplicaron en sus fichas (retrato nuevo y bloque «Su nombre» con quien lo propuso), El juego, portada, La causa, Biblioteca, Cuentos, Tienda, Primera partida, Paquete de guardián, consola y explorador. `data/cartas.json` suma el campo `guardian` a los 15 guardianes: la consola y el explorador muestran «NOMBRE · especie». Nueva sección **Novedades** (`novedades.html`, en el menú y el pie del portal, con aviso en la portada): cartel del resultado (WebP y PDF en `novedades/`) y bitácora de lo publicado desde septiembre. `scripts/generar-sitio.mjs` vuelve a correr: acepta guardianes del mazo sin ficha en el portal (ÁMBAR, BALEY, CIMA, INIA, CRUM; los avisa) y cuenta 15 guardianes. Para que el zip completo vuelva a pesar menos de 25 MB, los 10 cuentos se recomprimieron para pantalla (26.8 → 13.4 MB; texto verificado legible) y el título de la consola bajó a 1600 px. `contentRevision v13-7-nombres-wanha`.
>
> **V13.6 · 2026-11-01.** Los 5 Guardianes nuevos (ÁMBAR, BALEY, CIMA, INIA, CRUM) completan sus 400 cartas en **maya yucateco (MY)**: con esto quedan en **8 idiomas** (ES·EN·FR·IT·PT·ZH·NA·MY, 0 huecos × 400 en cada uno). El explorador y la consola ofrecen **maya y náhuatl vivos en el selector, sin marca de «en revisión»** para estos Guardianes (decisión de Jorge). Registro MY: ortografía práctica con glotalizadas por apóstrofo (k' t' ts' ch' p'), saltillo, préstamos del español para fauna no local y técnica (péepen=monarca, lobo, ch'uuy=águila, boto, pingüino, algodoncillo/oyamel), « » para citas, trivia impersonal, títulos de trivia rellenados (la base MY no los traía). Nota de producción (no de cara al sitio): EN·FR·IT·PT·ZH son fiables; NA y MY son borrador y conviene pulir la redacción con hablante nativo más adelante — queda pendiente para una pasada futura, no bloquea esta publicación. `build 202611012000` · `contentRevision v13-6-400-es-en-fr-it-pt-zh-na-my`.
>
> **V13.5 · 2026-11-01.** Los 5 Guardianes nuevos (ÁMBAR, BALEY, CIMA, INIA, CRUM) ya tienen sus 400 cartas en **náhuatl (NA)** además de español, inglés, francés, italiano, portugués y chino (7 idiomas, 0 huecos × 400). El explorador y la consola ofrecen NA para ellos. Registro NA: ortografía práctica, variante central, préstamos del español como la base (papalotl, kuetlachtli, kwautli, delfín koskatik/boto, pingüino), trivia impersonal, 你们→nombres plurales en los retos. **⚠️ El náhuatl de los 5 nuevos es un BORRADOR DE MÁQUINA SIN REVISIÓN DE HABLANTE NATIVO** — no debe publicarse como definitivo sin esa revisión; el náhuatl tiene variantes y hay riesgo real de errores gramaticales y léxicos. Pendiente único: MY (maya yucateco), también a producir con revisión nativa. `build 202611011800` · `contentRevision v13-5-400-es-en-fr-it-pt-zh-na`.
>
> **V13.4 · 2026-11-01.** Los 5 Guardianes nuevos (ÁMBAR, BALEY, CIMA, INIA, CRUM) ya tienen sus 400 cartas en **chino (中文, simplificado)** además de español, inglés, francés, italiano y portugués (6 idiomas, 0 huecos × 400). El explorador y la consola ofrecen ZH para ellos. Registro ZH: chino simplificado, puntuación de ancho completo, nombres de animales en chino (帝王蝶 / 墨西哥狼 / 金雕 / 亚马逊河豚 / 加拉帕戈斯企鹅), trivia impersonal, 你们 en los retos familiares. En G04 la paridad de longitud se mide con tolerancia ±15% o ±3 caracteres. Pendientes aún: MY (maya), NA (náhuatl). El chino de los 5 nuevos **no tiene revisión de hablante nativo** todavía. `build 202611011600` · `contentRevision v13-4-400-es-en-fr-it-pt-zh`.
>
> **V13.3 · 2026-11-01.** Los 5 Guardianes nuevos (ÁMBAR, BALEY, CIMA, INIA, CRUM) ya tienen sus 400 cartas en **portugués (Brasil)** además de español, inglés, francés e italiano (5 idiomas, 0 huecos × 400). El explorador y la consola ofrecen PT para ellos. Registro PT: «vocês» en los retos, português do Brasil informal (você/a gente), tipografía con « » y trivia impersonal. Pendientes aún: MY (maya), NA (náhuatl), ZH. El portugués de los 5 nuevos **no tiene revisión de hablante nativo** todavía. `build 202611011400` · `contentRevision v13-3-400-es-en-fr-it-pt`.
>
> **V13.2 · 2026-11-01.** Los 5 Guardianes nuevos (ÁMBAR, BALEY, CIMA, INIA, CRUM) ya tienen sus 400 cartas en **italiano** además de español, inglés y francés (4 idiomas, 0 huecos × 400). El explorador y la consola ofrecen IT para ellos (declarado en `langs` + completo en datos). Registro IT: tratamiento "voi", tipografía italiana (sin espacio antes de puntuación, « » caporali, apóstrofo recto), trivia impersonal. Pendientes aún: MY (maya), NA (náhuatl), PT, ZH. El italiano de los 5 nuevos **no tiene revisión de hablante nativo** todavía. `build 202611011200` · `contentRevision v13-2-400-es-en-fr-it`.
>
> **V13.1 · 2026-10-31.** Los 5 Guardianes nuevos (ÁMBAR, BALEY, CIMA, INIA, CRUM) ya tienen sus 400 cartas en **francés** además de español e inglés; el explorador ofrece FR para ellos. Pendientes aún: MY, NA, PT, ZH, IT.
>
> **V13.0 · 2026-10-31.** Se sumaron **5 Guardianes nuevos** — ÁMBAR (Mariposa Monarca), BALEY (Lobo Mexicano), CIMA (Águila Real), INIA (Delfín Rosado) y CRUM (Pingüino de Galápagos) — con **400 cartas nuevas en español e inglés** (20 por tipo cada uno). **Total del mazo: 1.200 cartas · 15 Guardianes.** Se publicaron los **5 cuentos ilustrados** nuevos en `docs/cuentos/` y se reconstruyó la **Tienda** (`tienda.html`) como armador de pedido con Orden de Compra por WhatsApp. Canon del lobo: el Guardián se llama **BALEY** (cartas, tienda y sitio). En el cuento, la joven loba protagonista se llama **Bruna**; la portada ilustrada aún dice «BRUNA» y requiere regenerar el arte para rotularla «BALEY».
>
> **V12 · Versiones separadas (DOC-01).** Esquema de datos: V22.0-unified · Contenido: ver `contentRevision` en data/sitio.json · Reglamento: **por confirmar** (los PDF dicen V9.6 en el nombre y V9.5 en la portada; el sitio dice «Reglamento de FAUNA Guardianes» hasta resolverlo) · Build: lo genera `scripts/generar-sitio.mjs`.

> Actualización 2026-10-12: se sumó VITA (Vaquita Marina, Alto Golfo de California) como décimo guardián con 80 cartas (20 por tipo) en español, inglés y francés. Total del mazo: 800. Las cifras de abajo describen la base V9.6 de 720.

# FAUNA Guardianes — Consola (Sitio único) · V22.0-unified

Un solo lugar para jugar con **los 9 guardianes** (y los que vengan). Sustituye a los dos
micrositios anteriores (Wanha' + edición multilingüe).

## Qué hace
- **Mazo unificado:** 720 cartas · 9 guardianes · 180 por tipo (Pulso / Encuentro / Reto / Trivia).
- **Partida mixta:** eliges de 2 a 4 guardianes en mesa; cualquier carta puede salir de cualquiera. Reglas idénticas (motor V12.0).
- **Multilingüe sin reserva a español (build 202609040230):** un idioma solo se ofrece si el guardián lo declara en el registro **y** tiene cartas completas en él. En el setup aparecen solo los idiomas que *todos* los guardianes en mesa tienen; en juego, la barra muestra solo los de la carta en turno. Se eligen **uno o varios** y la carta se lee apilada en el orden elegido. Si una carta no existe en lo elegido, se lee en español y la cabecera lo dice (“· sin Maya”). Nunca aparece español bajo la etiqueta de otro idioma.
- **Lectura primero:** la tarjeta es la protagonista. Dados con diseño, marcador y narrador quedan discretos abajo.

## Guardianes e idiomas
| Código | Guardián | Bioma | Idiomas |
|---|---|---|---|
| MGL | Mangle Rojo | Manglar relicto · río San Pedro | ES |
| ESP | Espátula Rosada | Corredor de humedales | ES |
| ROB | Róbalo | Corredor río–mar | ES |
| SAR | Saraguato Negro | Selva alta | ES |
| MEL | Abeja Melipona | Red florida · meliponicultura | ES |
| AXO | Ajolote | Xochimilco | ES · EN · Maya · FR · Náhuatl · PT |
| BALAM | Jaguar | Selva Maya | ES · EN · Maya · FR · Náhuatl · PT |
| LUMA | Guacamaya | Bosque Nublado | ES · EN · Maya · FR · Náhuatl · PT |
| CORAL | Coral | Arrecife Mesoamericano | ES · EN · Maya · FR · Náhuatl · PT |

## Estructura
```
index.html            · consola (shell)
css/consola.css       · diseño original + barra de idioma
js/consola.js         · motor único (registro de guardianes + capa multilingüe)
js/fauna-log.js       · analítica opcional (silenciosa sin conexión)
data/cartas.json      · registros: guardianes[], idiomas[], cartas[]
dados/                · dados con diseño (acc / dir / art · 0–5)
assets/               · título e íconos alternos (villanos, rumbos, categorías)
docs/                 · documentos para imprimir (botón ▣ Documentos)
docs/cuentos/         · cuentos ilustrados por Guardián (PDF de lectura + portadas)
icons/, manifest.webmanifest, sw.js   · PWA / offline
```

## Agregar el guardián #10 (extensible)
1. En `data/cartas.json`, añade sus cartas al arreglo `cartas` (mismo esquema; las variantes por idioma usan sufijos `__EN`, `__MY`, `__FR`, `__NA`, `__PT`).
2. Añade una entrada a `guardianes[]` con `code`, `name`, `bioma`, `color`, `langs`, `edicion`.
3. Listo — aparece en el setup, en la barra de idioma contextual y en el mazo. **Sin tocar el código.**

## Notas de fusión (decisiones)
- **Base = motor “consola” de Wanha'** (lectura primero; marcador y narrador discretos). Es el diseño que se pidió preservar.
- **Dados con diseño = los de Wanha'** (el motor ya los usa). Los íconos de la otra edición quedan en `assets/` por si se prefieren luego.
- **Escalera de RETO localizada:** ahora muestra también la instrucción de “Lo intentaré” en el idioma elegido; el token (Reserva +N) se deriva del texto.
- **Cobertura real por idioma (build 202609040230):** Wanha’ (MGL/ESP/ROB/SAR/MEL) 80/80 en ES·EN·FR·NA·ZH·IT. Guardianes (AXO/BALAM/LUMA/CORAL) 80/80 en ES·EN·MY·FR·NA·PT. 720/720 completas en todos los idiomas que declara cada guardián.

---
## Actualización V22.1 — portada, explorador y sin tope de guardianes
- **Portada (`index.html`)** — entrada del sitio: título watercolor, franja viva de los 9 guardianes (se llena desde el registro) y tres accesos: **Jugar**, **Explorar las cartas**, **Documentos**.
- **Consola (`consola.html`)** — el juego. El logo vuelve a la portada; arriba a la derecha, accesos discretos a **Cartas** y **Documentos**.
- **Explorador (`cartas.html`)** — las 720 cartas de los 9 guardianes, con filtros por guardián, tipo y **barra de idioma** (solo los idiomas del guardián en turno; uno o varios; el idioma filtra: nunca reserva a español). Toca una carta para leerla completa.
- **Sin tope de 4**: en el setup ya eliges **los guardianes que gustes** (mínimo 2, sin máximo).

Flujo: `index.html` (portada) → `consola.html` (jugar) ↔ `cartas.html` (explorar) · `docs/` (imprimir).

## Contacto (build 202609040230)
- `contacto.html`: tarjeta digital (Tapni), canales directos, botón «Guardar contacto» (.vcf generado en el navegador), QR del sitio con «copiar enlace» y «compartir».
- Todo se alimenta de **`data/contacto.json`**: los canales con `valor` vacío no se muestran; el `href` se arma solo (wa.me, mailto:, tel:, instagram.com/…). Para cambiar un dato basta editar ese archivo.
- Botón «Contacto» en la portada (`index.html`).

## Chino (build 202609040230)
- `ZH` (中文 · 普通话) registrado en `idiomas`; las 720 cartas llevan campos `__ZH` completos. Guardianes: ES·EN·MY·FR·NA·PT·ZH; Wanha’: ES·EN·FR·NA·ZH.
- Chino simplificado, puntuación de ancho completo. Nombres de guardianes/villanos sin traducir; tokens de motor (Reserva/Daño/Refugio/Movimiento/±N) en español dentro de `Efecto__ZH`.
- El chino **no tiene revisión de hablante nativo**: usar `FAUNA_QA_MAESTRO_720_ES_ZH.csv` para esa revisión antes de anunciarlo como definitivo.

## Italiano (build 202609040230)
- `IT` (Italiano · Italia) registrado en `idiomas`; las 720 cartas llevan campos `__IT` completos. Guardianes: ES·EN·MY·FR·NA·PT·ZH·IT; Wanha’: ES·EN·FR·NA·ZH·IT.
- Glosario: mangrovia rossa/propagulo, spatola rosata, robalo (nombre del guardián), luccio alligatore tropicale (pejelagarto), scimmia urlatrice nera, ape melipona/jobón, axolotl/chinampas, giaguaro, ara scarlatta/bosco nebuloso, pesce pappagallo/sbiancamento. Tokens de motor en español dentro de `Efecto__IT`.
- El italiano **no tiene revisión de hablante nativo**: usar `FAUNA_QA_MAESTRO_720_ES_IT.csv` para esa revisión antes de anunciarlo como definitivo.

## Dilemas por idioma (build 202609040230)
- Los 26 dilemas A/B (10 Wanha’ + 16 Guardianes) llevan `Efecto__XX` en cada idioma declarado por su guardián. Solo se traducen las etiquetas de A y B; los tokens del motor (`Reserva ±N`, `Daño -N`, `Refugio +N`, `Movimiento ±N`, `±N`, `luego`) permanecen en español para el parser y las cartas físicas.
- Explorador y consola muestran el dilema apilado por idioma elegido, y los nombres de los chips (Reserva/Daña/Restaura/Funda Refugio/luego) se localizan desde un diccionario en el renderer (`TOKL`), no en los datos.
- El parser ahora reconoce también `Daño -N` y `Refugio +N` (formas de la edición Guardianes) que antes salían crudos; la consola trocea las ramas de dilema en chips individuales.
- Normalización: se retiraron 304 `Efecto__EN` y 304 `Efecto__MY` de cartas simples de Guardianes (contenían tokens traducidos como `Damage -1`/`Loob -1`, sin información propia y rompían el parser). Las etiquetas maya de los 16 dilemas se conservaron; se recompusieron con tokens en español.
- Chip labels MY/NA (`Reserva múuch'kaab`, `Loob`, `Péek`, `Kanan`; `Tlapiyalli`, `Kitlakoa`, `Kiyektlalia`) sin revisión de hablante nativo.

---
## Reglamento V9.5 y consecuencias uniformes (build 202609121500)
- `docs/FAUNA_Reglamento_V9_5.pdf` sustituye al V8.5: escala de **cinco niveles** (−2..+2), Villanos empiezan en **2** (dial de dificultad: baja tras dos derrotas seguidas, sube tras dos victorias), Pausa es Pausa, Cooperar sin dos turnos seguidos, motor uniforme. 16 páginas carta. Validado con simulación (10,000 partidas por nivel de ventaja).
- **Consecuencias en `data/cartas.json`** normalizadas al lenguaje del reglamento: `+N` (proteger), `-N` (dañar), `Reserva ±N`. Desaparecen `Movimiento +N` (→ `+1`), `Refugio +1` (→ `+2`) y la forma `Daño -N` (→ `+N`, que la consola mostraba como "Daña"). Aplicado también a `Efecto__XX` de los dilemas. 193 campos en 88 cartas (`revision_cartas/consecuencias_cambios.csv`).
- **Reto:** `→ Efecto` ("Ya lo hago") vale `+1` o `+2` según lo que cuesta el hábito (90 de 180 en +2); `Lo intentaré` = `Reserva +1`; `Paso` = 0. Lista revisable en `revision_cartas/retos_ya_lo_hago.csv`.
- **Trivia:** nuevo campo `I · Premio` (`+1`/`+2`) en las 180 cartas: premio de Intermedio según dificultad de la pregunta (98 en +2). Principiante +1, Avanzado +2, fallo −1 en cualquier nivel. La consola muestra el premio del nivel elegido y el mensaje de resultado sigue el V9.5 (casilla propia o adyacente, tú eliges).
- **Consola:** el marcador de los Villanos inicia en 2; encabezado "Reglamento V9.5".
- **Distractores de Trivia (ES), build 202609111500:** reescritos los 480 distractores de la edición Guardianes (AXO, BALAM, LUMA, CORAL: 240 preguntas). Correcta = la más larga: AXO 35%, BALAM 28%, LUMA 20%, CORAL 23% (antes 85–98%); paridad ±15%: 97–100%. Wanha' (MGL, ESP, ROB, SAR, MEL) revisado en el build 202609111800: 256 ajustes de longitud sobre los distractores existentes; paridad 98–100% y correcta estrictamente más larga en 17–27%. Las 540 Trivias quedan sin sesgo de longitud en español. **Inglés (build 202609121500):** los 480 distractores nuevos de AXO/BALAM/LUMA/CORAL ya están traducidos en `__EN` con paridad de longitud propia del inglés (98–100%). **Wanha' en inglés cerrado (build 202609121500):** 353 ajustes de longitud en `__EN` (MGL, ESP, ROB, SAR, MEL), alineando además 9 opciones cuyo sentido cambió en español. Inglés de las 540 Trivias: paridad 100%, correcta estrictamente más larga en 31%. **Francés (build 202609121500):** 480 distractores nuevos en la edición Guardianes y ajuste de longitud en Wanha'; 540 Trivias con paridad 100% (salvo una respuesta de una palabra, ROB-08 Intermedio) y correcta estrictamente más larga en 35%. **Portugués (build 202609121500):** 480 distractores nuevos en AXO, BALAM, LUMA y CORAL (única edición con PT); paridad 100% salvo CORAL-06 Avanzado (una palabra), correcta estrictamente más larga en 33–35%. **Italiano, edición Guardianes (build 202609121500):** 480 distractores nuevos en AXO, BALAM, LUMA y CORAL; paridad 100% salvo dos respuestas de una o dos palabras (CORAL-02 y 06 Avanzado). **Italiano de Wanha' (build 202609121500):** 263 ajustes de longitud; italiano de las 540 Trivias con paridad 99% (excepciones de una palabra: ROB-08 Intermedio, SAR-13 Principiante, CORAL-02 y 06 Avanzado) y correcta estrictamente más larga en 35%. **Chino, edición Guardianes (build 202609121500):** 480 distractores nuevos en AXO, BALAM, LUMA y CORAL. En chino la paridad se mide con tolerancia de ±15% o ±3 caracteres (lo que sea mayor), porque con respuestas de 15–25 caracteres un 15% equivale a 2–3 caracteres, diferencia visualmente imperceptible. Paridad 100%, correcta estrictamente más larga en 33–37%. **Chino de Wanha' (build 202609121500):** 289 ajustes; chino de las 540 Trivias con paridad 100% (tolerancia ±15% o ±3 caracteres) y correcta estrictamente más larga en 36%. **Náhuatl y maya (build 202609121500):** distractores nuevos en náhuatl (AXO, BALAM, LUMA, CORAL) y ajuste de longitud en Wanha'; distractores nuevos en maya yucateco (AXO, BALAM, LUMA, CORAL). Con esto los ocho idiomas del sitio quedan con respuestas de longitud equilibrada.
