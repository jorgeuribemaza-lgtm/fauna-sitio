/* La Fábrica Inventiva · núcleo compartido (CTX-01, QUI-01, FOR-01/02, MIK-01, MED-01)
   Cargar ANTES de sitio.js y de cualquier script consumidor.
   Los datos llegan de window.LFI_DATA (insertado por scripts/generar-sitio.mjs desde data/sitio.json). */
(function (w, d) {
  'use strict';
  var DATA = w.LFI_DATA || null;
  var LFI = w.LFI = w.LFI || {};
  /* Idioma de la página: <html lang="en"> usa los textos en inglés */
  var EN = /^en\b/i.test((d.documentElement && d.documentElement.getAttribute('lang')) || '');
  function T(es, en) { return EN ? en : es; }
  LFI.lang = EN ? 'en' : 'es'; LFI.T = T;
  var readyCbs = [];
  var isReady = false;

  /* ---------- almacenamiento tolerante a fallos ---------- */
  var mem = {};
  function store(kind) {
    try { var s = w[kind]; var k = '__lfi_t'; s.setItem(k, '1'); s.removeItem(k); return s; } catch (e) { return null; }
  }
  var LS = store('localStorage'), SS = store('sessionStorage');
  function getJSON(key, s) {
    s = s || LS;
    try { var raw = s ? s.getItem(key) : mem[key]; return raw ? JSON.parse(raw) : null; } catch (e) { return null; }
  }
  function setJSON(key, val, s) {
    s = s || LS;
    var raw = JSON.stringify(val);
    try { if (s) { s.setItem(key, raw); return true; } } catch (e) {}
    mem[key] = raw; return false;
  }
  LFI.storage = { local: !!LS, session: !!SS, getJSON: getJSON, setJSON: setJSON };

  /* ---------- registro ---------- */
  var CODES = ['MGL','ESP','ROB','SAR','MEL','AXO','BALAM','LUMA','CORAL','VITA','AMBAR','BALEY','CIMA','INIA','CRUM'];
  function byCode() {
    var idx = {};
    if (DATA && DATA.guardians) DATA.guardians.forEach(function (g) { idx[g.code] = g; });
    return idx;
  }
  LFI.guardianByCode = byCode();
  LFI.codes = CODES.slice();
  function normCode(v) {
    if (typeof v !== 'string') return null;
    var c = v.trim().toUpperCase();
    return CODES.indexOf(c) >= 0 ? c : null;
  }
  LFI.normCode = normCode;
  LFI.nameOf = function (code) { var g = LFI.guardianByCode[code]; return g ? g.displayName : code; };

  /* ---------- parámetros de URL ---------- */
  function params() { try { return new URLSearchParams(w.location.search); } catch (e) { return null; } }
  function replaceParams(mut) {
    try {
      var u = new URL(w.location.href);
      mut(u.searchParams);
      w.history.replaceState(w.history.state, '', u.pathname + (u.searchParams.toString() ? '?' + u.searchParams : '') + u.hash);
    } catch (e) {}
  }
  LFI.replaceParams = replaceParams;

  /* ---------- CTX-01: contexto de guardián único ---------- */
  var CTX_KEY = 'lfi_guardian_v1';
  var ctxMemory = null;
  LFI.guardianContext = {
    /* prioridad: ?g válido > guardado válido > defecto. ?g inválido se retira de la URL. */
    resolve: function (fallback) {
      var p = params(), raw = p ? p.get('g') : null;
      if (raw !== null) {
        var c = normCode(raw);
        if (c) { this.save(c); if (raw !== c) replaceParams(function (s) { s.set('g', c); }); return c; }
        replaceParams(function (s) { s.delete('g'); });
        return fallback || null;
      }
      var saved = this.saved();
      return saved || fallback || null;
    },
    saved: function () {
      if (ctxMemory) return ctxMemory;
      var o = getJSON(CTX_KEY);
      return o && o.version === 1 ? normCode(o.code) : null;
    },
    save: function (code) {
      code = normCode(code); if (!code) return;
      ctxMemory = code; setJSON(CTX_KEY, { version: 1, code: code });
    },
    clear: function () {
      ctxMemory = null;
      try { if (LS) LS.removeItem(CTX_KEY); } catch (e) {}
      delete mem[CTX_KEY];
    },
    /* al cambiar filtro o selección única */
    set: function (code) {
      code = normCode(code);
      if (!code) { this.clear(); replaceParams(function (s) { s.delete('g'); }); return; }
      this.save(code); replaceParams(function (s) { s.set('g', code); });
    }
  };

  /* Enlaces [data-guardian-code]: transmiten el contexto al pulsar */
  d.addEventListener('click', function (ev) {
    var a = ev.target.closest && ev.target.closest('[data-guardian-code]');
    if (!a) return;
    var c = normCode(a.getAttribute('data-guardian-code'));
    if (c) LFI.guardianContext.save(c);
  }, true);

  /* ---------- PIE-01: pareja de Primera partida ---------- */
  var FP_KEY = 'lfi_first_party_v1';
  LFI.firstParty = {
    resolve: function () {
      var def = (DATA && DATA.defaults && DATA.defaults.firstPartyPair) || ['AXO', 'BALAM'];
      var p = params();
      var has = p && (p.has('g1') || p.has('g2') || p.has('g'));
      var g1 = null, g2 = null, repeated = false, dirty = false;
      if (has) {
        var r1 = p.get('g1'), r2 = p.get('g2');
        if (r1 === null && p.has('g')) r1 = p.get('g');
        g1 = normCode(r1); g2 = normCode(r2);
        if (r1 !== null && !g1) dirty = true;
        if (r2 !== null && !g2) dirty = true;
        if (g1 && g2 && g1 === g2) { repeated = true; g2 = null; }
      } else {
        var s = getJSON(FP_KEY);
        if (s && s.version === 1) {
          var a = normCode(s.g1), b = normCode(s.g2);
          if (a && b && a !== b) { g1 = a; g2 = b; }
        }
      }
      function fill(taken) { for (var i = 0; i < def.length; i++) if (def[i] !== taken) return def[i]; return null; }
      if (!g1) g1 = fill(g2);
      if (!g2) g2 = fill(g1);
      if (has || dirty) this.reflect(g1, g2);
      return { g1: g1, g2: g2, repeated: repeated };
    },
    save: function (g1, g2) {
      g1 = normCode(g1); g2 = normCode(g2);
      if (!g1 || !g2 || g1 === g2) return false;
      setJSON(FP_KEY, { version: 1, g1: g1, g2: g2 });
      this.reflect(g1, g2);
      return true;
    },
    reflect: function (g1, g2) {
      replaceParams(function (s) { s.delete('g'); s.set('g1', g1); s.set('g2', g2); });
    },
    repeatedMessage: T('Tu mesa necesita dos guardianes distintos. Te dejamos una segunda opción; puedes cambiarla.', 'Your table needs two different Guardians. We picked a second one for you; you can change it.')
  };

  /* ---------- QUI-01: barajado Fisher–Yates por sourceKey ---------- */
  LFI.shuffleOptions = function (opts, rand) {
    rand = rand || Math.random;
    var arr = opts.map(function (o) { return { sourceKey: o.sourceKey, text: o.text }; });
    for (var i = arr.length - 1; i > 0; i--) {
      var j = Math.floor(rand() * (i + 1)); var t = arr[i]; arr[i] = arr[j]; arr[j] = t;
    }
    return arr;
  };
  /* Generador determinista para pruebas */
  LFI.seededRandom = function (seed) {
    var s = seed >>> 0;
    return function () { s = (s + 0x6D2B79F5) >>> 0; var t = s; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  };

  /* ---------- FOR-02: validaciones ---------- */
  var CTRL = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/;
  var CTRL_OR_NL = /[\u0000-\u001F\u007F]/;
  function clean(v) { return String(v == null ? '' : v).replace(/\s+/g, ' ').trim(); }
  function len(v) { return Array.from(v).length; }
  LFI.validate = {
    quantity: function (raw, unitPrice) {
      raw = String(raw == null ? '' : raw).trim();
      if (!/^[1-9][0-9]*$/.test(raw)) return { ok: false, code: raw ? 'invalid_integer' : 'required', msg: T('¿Cuántas mesas vamos a despertar? Escribe una cantidad entera a partir de 1.', 'How many tables shall we wake up? Enter a whole number, 1 or more.') };
      var q = Number(raw);
      if (!Number.isSafeInteger(q) || (unitPrice && !Number.isSafeInteger(q * unitPrice))) return { ok: false, code: 'invalid_integer', msg: T('¿Cuántas mesas vamos a despertar? Escribe una cantidad entera a partir de 1.', 'How many tables shall we wake up? Enter a whole number, 1 or more.') };
      return { ok: true, value: q };
    },
    city: function (raw) {
      var v = clean(raw);
      if (!v) return { ok: false, code: 'required', msg: T('Dinos tu ciudad para conversar sobre el envío.', 'Tell us your city so we can talk about shipping.') };
      if (len(v) < 2 || len(v) > 100 || CTRL_OR_NL.test(String(raw).replace(/[\r\n\t]/g, ' '))) return { ok: false, code: 'invalid_text', msg: T('Dinos tu ciudad para conversar sobre el envío.', 'Tell us your city so we can talk about shipping.') };
      return { ok: true, value: v };
    },
    optionalText: function (raw, max) {
      var v = String(raw == null ? '' : raw).trim();
      if (!v) return { ok: true, value: '' };
      if (CTRL.test(v)) return { ok: false, code: 'invalid_text', msg: T('Este texto tiene caracteres que no podemos enviar.', 'This text has characters we cannot send.') };
      if (len(v) > max) return { ok: false, code: 'too_long', msg: T('Máximo ', 'Maximum ') + max + T(' caracteres.', ' characters.') };
      return { ok: true, value: v };
    },
    requiredText: function (raw, min, max, msg) {
      var v = String(raw == null ? '' : raw).trim();
      if (!v) return { ok: false, code: 'required', msg: msg };
      if (CTRL.test(v)) return { ok: false, code: 'invalid_text', msg: msg };
      if (len(v) < min || len(v) > max) return { ok: false, code: len(v) > max ? 'too_long' : 'required', msg: msg };
      return { ok: true, value: v };
    },
    guardian: function (raw) {
      var c = normCode(raw);
      return c ? { ok: true, value: c } : { ok: false, code: 'invalid_code', msg: T('Elige un guardián de la lista.', 'Choose a Guardian from the list.') };
    }
  };

  /* Pintar / limpiar errores accesibles junto al campo */
  LFI.fieldError = function (input, msg) {
    if (!input) return;
    var id = (input.id || 'f') + '-err';
    var el = d.getElementById(id);
    if (msg) {
      if (!el) { el = d.createElement('p'); el.id = id; el.className = 'lfi-error'; input.insertAdjacentElement('afterend', el); }
      el.textContent = msg;
      input.setAttribute('aria-invalid', 'true');
      var db = (input.getAttribute('aria-describedby') || '').split(' ').filter(Boolean);
      if (db.indexOf(id) < 0) { db.push(id); input.setAttribute('aria-describedby', db.join(' ')); }
    } else {
      if (el) el.remove();
      input.removeAttribute('aria-invalid');
      var rest = (input.getAttribute('aria-describedby') || '').split(' ').filter(function (x) { return x && x !== id; });
      if (rest.length) input.setAttribute('aria-describedby', rest.join(' ')); else input.removeAttribute('aria-describedby');
    }
  };

  /* ---------- FOR-01: WhatsApp ---------- */
  LFI.waURL = function (message) {
    var n = (DATA && DATA.brand && DATA.brand.whatsapp) || '525543524982';
    return 'https://wa.me/' + n + '?text=' + encodeURIComponent(message);
  };
  LFI.money = function (n) { return '$' + Number(n).toLocaleString('es-MX') + ' MXN'; };
  LFI.storyLine = function (code) {
    var g = LFI.guardianByCode[code]; if (!g || !DATA) return '';
    return (EN ? 'Includes the story of {nombre}.' : DATA.notices.storyIncluded).replace('{nombre}', g.displayName);
  };

  /* ---------- MED-01: medición (sin destino por defecto) ---------- */
  var ALLOWED = {
    pagina_vista: ['page_type','view_id','entrada','referrer_host','utm_source','utm_medium','utm_campaign','viewport'], pagina_tiempo: ['view_id','ms_visible','ms_total','envio'], historia_vista: ['section_id'], puerta_elegida: ['audience','destination_path'],
    guardian_seleccionado: ['guardian_code','guardian_codes','context','selection_source'],
    producto_visto: ['product_id','unit_price_mxn','currency'],
    configurador_cambiado: ['product_id','guardian_codes','quantity','subtotal_mxn','request_mode'],
    formulario_error: ['form_id','fields','error_codes','action'],
    consulta_iniciada: ['channel','form_id','product_id','request_mode','guardian_codes','quantity','subtotal_mxn','source_component'],
    mensaje_copiado: ['form_id','product_id','request_mode'],
    trivia_mostrada: ['question_instance_id','card_id','level','surface','guardian_code','langs'],
    trivia_respondida: ['question_instance_id','card_id','level','selected_source_key','selected_position','correct','surface','langs'],
    partida_iniciada: ['game_id','guardian_codes','guardian_count','langs','player_count'],
    carta_robada: ['game_id','draw_instance_id','card_id','card_type','guardian_code','langs'],
    dado_tirado: ['game_id','die_type','result'],
    marcador_cambiado: ['game_id','guardian_score','villain_score','cause'],
    turno_cambiado: ['game_id','turn_number','guardian_code'],
    partida_terminada: ['game_id','result','guardian_score','villain_score','turn_number'],
    idioma_cambiado: ['langs','surface'],
    compromiso_cambiado: ['guardian_code','value','completed_count'],
    fuente_abierta: ['source_id','card_id','guardian_code','review_kind'],
    evidencia_abierta: ['evidence_id','evidence_kind','asset_kind'],
    paquete_docente_abierto: ['source_component','resource_id'],
    recurso_descarga_iniciada: ['resource_id','resource_type','guardian_code'],
    huella_encontrada: ['paw_id','found_count'],
    recompensa_desbloqueada: ['reward_id','found_count'],
    recompensa_abierta: ['reward_id','source_component'],
    recompensa_impresion_iniciada: ['reward_id']
  };
  function uuid() {
    try { return crypto.randomUUID(); } catch (e) {
      return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) { var r = Math.random() * 16 | 0; return (c === 'x' ? r : (r & 3 | 8)).toString(16); });
    }
  }
  /* Identificador anónimo del navegador: la MISMA clave que usaba la consola de testers,
     así quien ya probó el juego cuenta una sola vez en el total de visitantes. */
  var deviceId = (function () {
    var k = 'fauna_device_id', v = null;
    try { v = LS && LS.getItem(k); if (!v) { v = Date.now().toString(36) + Math.random().toString(36).slice(2, 10); if (LS) LS.setItem(k, v); } } catch (e) {}
    return v || ('anon-' + uuid());
  })();
  var sessionId = (function () {
    try { var s = SS && SS.getItem('lfi_session_id'); if (s) return s; s = uuid(); if (SS) SS.setItem('lfi_session_id', s); return s; } catch (e) { return uuid(); }
  })();
  var queue = [], outbox = [], seen = {}, timer = null;
  function endpoint() { return (DATA && DATA.analyticsEndpoint) || null; }
  /* Contrato del colector existente (/collect): { events:[ {appVersion,event,ts,epochMs,deviceId,sessionId,testerCode,...,payload} ] } */
  function toLegacy(ev) {
    var payload = {};
    Object.keys(ev).forEach(function (k) { if (['event_name', 'event_id', 'occurred_at', 'session_id'].indexOf(k) < 0) payload[k] = ev[k]; });
    payload.event_id = ev.event_id;
    return { appVersion: 'sitio', edicion: 'lfi-v12', event: ev.event_name, ts: ev.occurred_at, epochMs: Date.parse(ev.occurred_at),
      deviceId: deviceId, sessionId: sessionId, testerCode: null, playerCount: null,
      activeGuardians: ev.guardian_codes || (ev.guardian_code ? [ev.guardian_code] : null),
      guardian_score: ev.guardian_score != null ? ev.guardian_score : null, villain_score: ev.villain_score != null ? ev.villain_score : null,
      scores: { g: null, v: null }, payload: payload };
  }
  function flush(unloading) {
    if (timer) { clearTimeout(timer); timer = null; }
    var url = endpoint(); if (!url || !outbox.length) { outbox.length = 0; return; }
    var batch = outbox.splice(0, outbox.length);
    /* Al salir de la página: sendBeacon con texto plano (no necesita permiso previo del servidor y sobrevive a la navegación). */
    if (unloading && w.navigator.sendBeacon) {
      try { if (w.navigator.sendBeacon(url, new Blob([JSON.stringify({ events: batch })], { type: 'text/plain;charset=UTF-8' }))) return; } catch (e) {}
    }
    try {
      fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ events: batch }), keepalive: true, mode: 'cors' })
        .catch(function () {});
    } catch (e) {}
  }
  LFI.flush = flush;
  LFI.track = function (name, p) {
    try {
      var allow = ALLOWED[name]; if (!allow) return null;
      var ev = {
        event_name: name, event_id: uuid(), occurred_at: new Date().toISOString(), session_id: sessionId,
        page_path: w.location.pathname, app_version: (DATA && DATA.buildId) || null,
        content_revision: (DATA && DATA.contentRevision) || null, rules_version: (DATA && DATA.rulesVersion) || null
      };
      p = p || {};
      allow.forEach(function (k) { if (k in p) ev[k] = p[k]; });
      if (seen[ev.event_id]) return null; seen[ev.event_id] = 1;
      if (queue.length >= 100) queue.shift();
      queue.push(ev);
      if (endpoint() && !/^(localhost|127\.)/.test(w.location.hostname)) {
        outbox.push(toLegacy(ev));
        if (name === 'pagina_vista' || outbox.length >= 20) flush(); else if (!timer) timer = setTimeout(flush, 4000);
      }
      if (typeof LFI.onTrack === 'function') { try { LFI.onTrack(ev); } catch (e) {} }
      return ev;
    } catch (e) { return null; }
  };
  LFI._queue = queue;

  /* ---------- Visitas: a dónde entran y cuánto duran (todo el sitio) ---------- */
  (function () {
    var viewId = uuid(), t0 = Date.now(), visibleMs = 0, visSince = d.visibilityState === 'visible' ? t0 : null, sent = 0;
    var entry = false;
    try { entry = !(SS && SS.getItem('lfi_entry_done')); if (SS) SS.setItem('lfi_entry_done', '1'); } catch (e) {}
    var refHost = null;
    try { if (d.referrer) { var r = new URL(d.referrer); refHost = r.hostname === w.location.hostname ? null : r.hostname; } } catch (e) {}
    var utm = {};
    try { var q = new URLSearchParams(w.location.search); ['utm_source', 'utm_medium', 'utm_campaign'].forEach(function (k) { var v = q.get(k); if (v) utm[k] = v.slice(0, 60); }); } catch (e) {}
    function start() {
      LFI.track('pagina_vista', { page_type: (d.body && d.body.getAttribute('data-page-type')) || 'other', view_id: viewId, entrada: entry,
        referrer_host: entry ? refHost : null, utm_source: utm.utm_source || null, utm_medium: utm.utm_medium || null, utm_campaign: utm.utm_campaign || null,
        viewport: (w.innerWidth < 700 ? 'movil' : 'escritorio') });
    }
    var lastAt = 0;
    function report(unloading) {
      var now = Date.now();
      if (now - lastAt < 1500) return; lastAt = now;   /* visibilitychange y pagehide llegan juntos: un solo reporte */
      if (visSince != null) { visibleMs += now - visSince; visSince = d.visibilityState === 'visible' ? now : null; }
      sent++;
      LFI.track('pagina_tiempo', { view_id: viewId, ms_visible: visibleMs, ms_total: now - t0, envio: sent });
      flush(unloading);
    }
    d.addEventListener('visibilitychange', function () {
      if (d.visibilityState === 'hidden') report(true); else visSince = Date.now();
    });
    w.addEventListener('pagehide', function () { report(true); });
    if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', start); else start();
  })();

  /* ---------- Contador público de visitantes ---------- */
  LFI.visitorCount = function (cb) {
    var url = DATA && DATA.statsEndpoint; if (!url) return;
    var K = 'lfi_contador_v1', c = getJSON(K, SS);
    if (c && Date.now() - c.t < 10 * 60 * 1000) return cb(c.n);
    try {
      fetch(url, { mode: 'cors' }).then(function (r) { return r.ok ? r.json() : null; }).then(function (j) {
        if (!j || typeof j.visitantes !== 'number') return;
        var n = j.visitantes + ((DATA && DATA.visitorBaseline) || 0);
        setJSON(K, { t: Date.now(), n: n }, SS); cb(n);
      }).catch(function () {});
    } catch (e) {}
  };

  /* ---------- MIK-01: huellas de Mika ---------- */
  var PAWS = (DATA && DATA.pawIds) || ['index','fauna','atelier','biblioteca','tienda','encargos','taller','aliados'];
  LFI.paws = {
    mode: LS ? 'local' : (SS ? 'session' : 'memory'),
    read: function () {
      var raw = LS ? getJSON('lfi_huellas', LS) : (SS ? getJSON('lfi_huellas_session', SS) : getJSON('lfi_huellas_mem', null));
      if (!Array.isArray(raw)) return [];
      var out = [];
      raw.forEach(function (x) { if (typeof x === 'string' && PAWS.indexOf(x) >= 0 && out.indexOf(x) < 0) out.push(x); });
      return out;
    },
    add: function (id) {
      if (PAWS.indexOf(id) < 0) return { added: false, count: this.read().length };
      var list = this.read();
      if (list.indexOf(id) >= 0) return { added: false, count: list.length };
      var before = list.length; list.push(id);
      if (LS) setJSON('lfi_huellas', list, LS); else if (SS) setJSON('lfi_huellas_session', list, SS); else setJSON('lfi_huellas_mem', list, null);
      LFI.track('huella_encontrada', { paw_id: id, found_count: list.length });
      if (before === 7 && list.length === 8) LFI.track('recompensa_desbloqueada', { reward_id: 'mika_sheet', found_count: 8 });
      return { added: true, count: list.length, completedNow: before === 7 && list.length === 8 };
    },
    total: PAWS.length
  };

  /* ---------- Aviso de la versión en inglés (visitantes cuyo navegador no está en español) ---------- */
  (function () {
    try {
      if (EN) return;
      var alt = d.querySelector('link[rel="alternate"][hreflang="en"]'); if (!alt) return;
      var nl = w.navigator || {}, langs = (nl.languages && nl.languages.length ? nl.languages : [nl.language || '']);
      if (Array.prototype.some.call(langs, function (x) { return /^es\b/i.test(String(x)); })) return;
      if (getJSON('lfi_aviso_en_cerrado')) return;
      var show = function () {
        if (!d.body || d.querySelector('.lfi-en-bar')) return;
        var bar = d.createElement('div'); bar.className = 'lfi-en-bar'; bar.setAttribute('lang', 'en'); bar.setAttribute('role', 'note');
        bar.style.cssText = 'position:relative;z-index:60;display:flex;gap:14px;align-items:center;justify-content:center;flex-wrap:wrap;padding:9px 16px;background:#1F3A44;color:#F5ECD6;font:500 14px/1.4 Poppins,system-ui,sans-serif;text-align:center';
        var a = d.createElement('a'); a.href = alt.href; a.textContent = 'This site is also in English \u2192';
        a.style.cssText = 'color:#F5ECD6;text-decoration:underline;text-underline-offset:3px';
        var x = d.createElement('button'); x.type = 'button'; x.setAttribute('aria-label', 'Close'); x.textContent = '\u00d7';
        x.style.cssText = 'background:none;border:0;color:#F5ECD6;font-size:22px;line-height:1;cursor:pointer;padding:0 4px';
        x.addEventListener('click', function () { setJSON('lfi_aviso_en_cerrado', 1); bar.remove(); });
        bar.appendChild(a); bar.appendChild(x); d.body.insertBefore(bar, d.body.firstChild);
      };
      if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', show); else show();
    } catch (e) {}
  })();

  /* ---------- ready ---------- */
  LFI.ready = function (cb) { if (isReady) { try { cb(LFI); } catch (e) {} } else readyCbs.push(cb); };
  function fire() { isReady = true; readyCbs.splice(0).forEach(function (cb) { try { cb(LFI); } catch (e) { if (w.console) console.error(e); } }); }
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', fire); else fire();
})(window, document);
