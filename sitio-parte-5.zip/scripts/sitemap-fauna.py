# -*- coding: utf-8 -*-
"""FAUNA Guardianes · sitemap.xml con fecha de última modificación y las páginas de lectura de cartas (V13.12).
Uso: python3 scripts/sitemap-fauna.py <AAAA-MM-DD de este build> [carpeta del sitio] [fechas.json]
Conserva el <lastmod> que ya tenga cada página; a las que no tienen les pone la fecha del build si cambiaron en él
(o la de fechas.json, ruta -> fecha, si se da). Las páginas de lectura de cartas se vuelven a listar con la fecha del build."""
import io, os, re, sys, json
HOY = sys.argv[1]
SITE = sys.argv[2] if len(sys.argv) > 2 else os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FECHAS = sys.argv[3] if len(sys.argv) > 3 else None
S = json.load(io.open(os.path.join(SITE, 'data/sitio.json'), encoding='utf-8')); ORIGIN = S['siteOrigin'].rstrip('/')
fechas = json.load(io.open(FECHAS, encoding='utf-8')) if FECHAS else {}          # ruta -> fecha del archivo en la entrega anterior
made = []
for d, L0 in (('cartas', 'ES'), ('en/cartas', 'EN')):
    dd = os.path.join(SITE, d)
    for f in sorted(os.listdir(dd)) if os.path.isdir(dd) else []:
        if not f.endswith('.html'): continue
        L = 'MY' if f.endswith('-maya.html') else 'NA' if f.endswith('-nahuatl.html') else L0
        made.append((d + '/' + f, L, 0))
old = io.open(os.path.join(SITE, 'sitemap.xml'), encoding='utf-8').read()
def url_to_file(u):
    p = u[len(ORIGIN):].lstrip('/')
    if p == '' or p.endswith('/'): return p + 'index.html'
    return p + '.html'
def changed(rel):
    """True si la página cambió en este build más allá del sello ?v= y la etiqueta robots."""
    a = io.open(os.path.join(SITE, rel), encoding='utf-8').read()
    return ('data-seo="v13-12"' in a) or ('data-lc="1"' in a)
out = ['<?xml version="1.0" encoding="UTF-8"?>', '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">']
seen = set(); n_old = 0
for blk in re.findall(r'<url>(.*?)</url>', old, re.S):
    loc = re.search(r'<loc>([^<]+)</loc>', blk).group(1)
    if '/cartas/' in loc: continue                                   # las de lectura se vuelven a escribir abajo
    rel = url_to_file(loc); assert os.path.exists(os.path.join(SITE, rel)), rel
    prev = re.search(r'<lastmod>([^<]+)</lastmod>', blk)
    lm = prev.group(1) if prev else (HOY if changed(rel) else fechas.get(rel, HOY))
    alts = re.findall(r'<xhtml:link[^>]*/>', blk)
    out.append('  <url>\n    <loc>%s</loc>\n    <lastmod>%s</lastmod>\n%s  </url>' % (loc, lm, ''.join('    %s\n' % a for a in alts)))
    seen.add(loc); n_old += 1
by = {}
for path, L, n in made: by.setdefault(L, []).append(path)
u = lambda p: ORIGIN + '/' + p[:-5]
n_new = 0
for path in by.get('ES', []):
    en = 'en/' + path
    pair = [(path, 'es'), (en, 'en')] if en in by.get('EN', []) else [(path, 'es')]
    for p, _ in pair:
        alts = ''
        if len(pair) == 2:
            alts = ''.join('    <xhtml:link rel="alternate" hreflang="%s" href="%s"/>\n' % (h, u(q)) for q, h in pair) + '    <xhtml:link rel="alternate" hreflang="x-default" href="%s"/>\n' % u(path)
        out.append('  <url>\n    <loc>%s</loc>\n    <lastmod>%s</lastmod>\n%s  </url>' % (u(p), HOY, alts)); n_new += 1
for L in ('MY', 'NA'):
    for path in by.get(L, []):
        out.append('  <url>\n    <loc>%s</loc>\n    <lastmod>%s</lastmod>\n  </url>' % (u(path), HOY)); n_new += 1
out.append('</urlset>\n')
io.open(os.path.join(SITE, 'sitemap.xml'), 'w', encoding='utf-8', newline='').write('\n'.join(out))
print('sitemap: %d anteriores + %d nuevas = %d' % (n_old, n_new, n_old + n_new))
