# -*- coding: utf-8 -*-
"""FAUNA Guardianes · páginas de lectura de las cartas (V13.12).
Genera cartas/<slug>.html (ES), en/cartas/<slug>.html (EN), cartas/<slug>-maya.html y cartas/<slug>-nahuatl.html
desde data/cartas.json y data/sitio.json. Toma el encabezado, el pie y los estilos de las fichas de guardián (fauna/<slug>.html),
respeta revision_bloqueos y no rellena con español lo que falta en otro idioma.
Uso: python3 scripts/cartas-lectura.py [carpeta del sitio]   (por omisión, la carpeta que contiene scripts/)
Después hay que correr scripts/seo-fauna.py, scripts/sitemap-fauna.py y, al final, node scripts/generar-sitio.mjs.
"""
import json, io, os, re, html, sys

SITE = sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
rd = lambda p: io.open(os.path.join(SITE, p), encoding='utf-8').read()
def wr(p, s):
    fp = os.path.join(SITE, p); os.makedirs(os.path.dirname(fp), exist_ok=True)
    io.open(fp, 'w', encoding='utf-8', newline='').write(s)
E = lambda s: html.escape(s or '', quote=False)
EQ = lambda s: html.escape(s or '', quote=True)

C = json.loads(rd('data/cartas.json')); S = json.loads(rd('data/sitio.json'))
ORIGIN = S['siteOrigin'].rstrip('/')
CARDS = C['cartas']; BLOQ = C.get('revision_bloqueos') or {}
DECK = {g['code']: g for g in C['guardianes']}
GS = S['guardians']

TOKL = {
 'ES': dict(reserva='Reserva', movim='Movimiento', refugio='Funda Refugio', restaura='Restaura', dana='Daña', nulo='Sin efecto'),
 'EN': dict(reserva='Reserve', movim='Movement', refugio='Found a Refuge', restaura='Restore', dana='Damage', nulo='No effect'),
 'MY': dict(reserva="Reserva múuch'kaab", movim='Péek', refugio='Ku beetik Kanan', restaura='Utskíintaj', dana='Loob', nulo="Mina'an"),
 'NA': dict(reserva='Tlapiyalli', movim='Olinilistli', refugio='Kitlalia Refugio', restaura='Kiyektlalia', dana='Kitlakoa', nulo='Amo tlen'),
}
def tag(tok, L):
    W = TOKL[L]; tok = (tok or '').strip()
    if tok in ('', '0'): return W['nulo']
    m = re.match(r'^Reserva\s*([+-]\d+)$', tok, re.I)
    if m: return W['reserva'] + ' ' + m.group(1).replace('-', '−')
    m = re.match(r'^Movimiento\s*([+-]\d+)$', tok, re.I)
    if m: return W['movim'] + ' ' + m.group(1).replace('-', '−')
    if re.match(r'^Refugio\s*\+?\d+$', tok, re.I): return W['refugio']
    m = re.match(r'^Da[ñn]o\s*-?(\d+)$', tok, re.I)
    if m: return W['dana'] + ' ' + m.group(1)
    m = re.match(r'^([+-])(\d+)$', tok)
    if m: return (W['restaura'] if m.group(1) == '+' else W['dana']) + ' ' + m.group(2)
    return tok
def tokens(raw, L):
    return ' · '.join(tag(t, L) for t in re.split(r'\s*·\s*', raw.strip()) if t.strip() != '' or raw.strip() == '')
def effect_html(raw, L, T):
    s = (raw or '').strip()
    if re.match(r'^A\)', s) and re.search(r'·\s*B\)', s):
        out = []
        for part in re.split(r'·\s*(?=B\))', s):
            m = re.match(r'^([AB])\)\s*([^:]+):\s*(.+)$', part.strip())
            if m: out.append('<li><b>%s.</b> %s <span class="lc-fx">%s</span></li>' % (m.group(1), E(m.group(2).strip()), E(tokens(m.group(3), L))))
        return '<ul class="lc-dil">' + ''.join(out) + '</ul>'
    return '<p class="lc-fx">%s %s</p>' % (E(T['mesa']), E(tokens(s, L)))

def F(c, field, L):
    return (c.get(field if L == 'ES' else field + '__' + L) or '').strip()
MAIN = {'TRIVIA': 'P · Pregunta', 'PULSO': 'Situación', 'ENCUENTRO': 'Escena', 'RETO': 'Consigna'}
def cards_of(code, tipo, L):
    out = []
    for c in CARDS:
        if c['Guardián'] != code or c['Tipo'] != tipo: continue
        if L != 'ES' and L in (BLOQ.get(c['ID'], {}).get('langs') or []): continue
        if not F(c, MAIN[tipo], L): continue
        out.append(c)
    return out

# ---------- textos de la página (los nombres y descripciones de mazo son los del sitio) ----------
def tiles(path):
    t = rd(path); o = {}
    for m in re.finditer(r'categoria-(\w+)\.png"[^>]*><b>([^<]+)</b><span>([^<]+)</span>', t):
        o[m.group(1)] = (html.unescape(m.group(2)), html.unescape(m.group(3)))
    return o
TIL = {'ES': tiles('fauna/index.html'), 'EN': tiles('en/fauna/index.html')}
assert len(TIL['ES']) == 4 and len(TIL['EN']) == 4, 'No encontré las cuatro descripciones de mazo en fauna/index.html'

TX = {
 'ES': dict(crumb_cards='Cartas', eyebrow='Su mazo completo · %d cartas', h1='Las %d cartas de %s', h1x='Las cartas de %s, en %s',
            intro='En la mesa salen de una en una y se leen en voz alta. Aquí está el mazo completo, para leerlo con calma.',
            jugar='Jugar una partida', explorador='Abrir el explorador', volver='← Volver a %s', leer_en='Léelas en',
            estado='Disponibles no siempre significa revisados por especialistas: lo contamos en <a href="%s" data-source-id="index" data-guardian="%s">Detrás de cada carta</a>.',
            estado_x='Esta traducción está disponible, con variante por confirmar y revisión lingüística pendiente. Lo contamos en <a href="%s" data-source-id="index" data-guardian="%s">Detrás de cada carta</a>.',
            sec={'TRIVIA': 'Trivia de %s', 'PULSO': 'Pulso de %s', 'ENCUENTRO': 'Encuentros de %s', 'RETO': 'Retos de %s'},
            n='%d cartas', lv={'P': 'Principiante', 'I': 'Intermedio', 'A': 'Avanzado'}, resp='Ver la respuesta', mesa='En la mesa:',
            ya='«Ya lo hago»', intento='«Lo intentaré»', paso='«Paso»', todas='Todas las cartas', toc='En esta página',
            title='Las %d cartas de %s | FAUNA Guardianes', titlex='Las cartas de %s, en %s | FAUNA Guardianes',
            desc='Lee completas las %d cartas de %s: trivias con su respuesta, pulsos, encuentros y retos de su territorio, %s.',
            descx='Las cartas de %s, en %s: trivias con su respuesta, pulsos, encuentros y retos de su territorio, %s.',
            terr='Su territorio: %s.', retrato='Retrato ilustrado de %s', juego='FAUNA Guardianes'),
 'EN': dict(crumb_cards='Cards', eyebrow='The full deck · %d cards', h1='The %d cards of %s', h1x='',
            intro='At the table they come up one at a time and are read aloud. Here is the whole deck, to read at your own pace.',
            jugar='Play a game', explorador='Open the card explorer', volver='← Back to %s', leer_en='Read them in',
            estado='“Available” does not always mean “reviewed by specialists”: we explain this in <a href="%s" data-source-id="index" data-guardian="%s">Behind every card</a>.',
            estado_x='',
            sec={'TRIVIA': '%s Trivia', 'PULSO': '%s Pulse', 'ENCUENTRO': '%s Encounters', 'RETO': '%s Challenges'},
            n='%d cards', lv={'P': 'Beginner', 'I': 'Intermediate', 'A': 'Advanced'}, resp='See the answer', mesa='At the table:',
            ya='“I already do it”', intento='“I\'ll try it”', paso='“Pass”', todas='All the cards', toc='On this page',
            title='The %d cards of %s | FAUNA Guardianes', titlex='',
            desc='Read all %d cards of %s: trivia with answers, pulses, encounters and challenges from its territory, %s.', descx='',
            terr='Territory: %s.', retrato='Illustrated portrait of %s', juego='FAUNA Guardianes'),
}
TIPOS = ['TRIVIA', 'PULSO', 'ENCUENTRO', 'RETO']
TKEY = {'TRIVIA': 'trivia', 'PULSO': 'pulso', 'ENCUENTRO': 'encuentro', 'RETO': 'reto'}
XL = {'MY': dict(slug='maya', nombre='maya', chip='Maya', lang='myn'), 'NA': dict(slug='nahuatl', nombre='náhuatl', chip='Náhuatl', lang='nah')}
CHIP = {'ES': 'Español', 'EN': 'English', 'MY': 'Maya', 'NA': 'Náhuatl'}

def guardian_info(g):
    es = rd('fauna/%s.html' % g['slug']); en = rd('en/fauna/%s.html' % g['slug'])
    h1 = lambda s: html.unescape(re.sub(r'<[^>]+>', '', re.search(r'<h1[^>]*>(.*?)</h1>', s, re.S).group(1))).strip()
    lead = lambda s: html.unescape(re.sub(r'<[^>]+>', '', re.search(r'<p class="lead">(.*?)</p>', s, re.S).group(1))).strip()
    face = re.search(r'<img class="gface"[^>]*src="([^"]+)"', es)
    col = re.search(r'--g:(#[0-9A-Fa-f]{6})', es)
    terr_en = re.sub(r'^Territory:\s*', '', lead(en)).rstrip('.')
    return dict(full_es=g.get('fullName') or h1(es), full_en=h1(en) if ',' in h1(en) else h1(en), terr_es=g['territory'], terr_en=terr_en,
                face=os.path.basename(face.group(1)) if face else None, color=col.group(1) if col else g.get('color', '#B4492A'))

def page_path(g, L):
    if L == 'ES': return 'cartas/%s.html' % g['slug']
    if L == 'EN': return 'en/cartas/%s.html' % g['slug']
    return 'cartas/%s-%s.html' % (g['slug'], XL[L]['slug'])
def page_url(g, L):
    return ORIGIN + '/' + page_path(g, L)[:-5]

def render_card(c, tipo, L, T, hl):
    """hl = atributo lang para el texto de la carta ('' si coincide con el de la página)."""
    la = (' lang="%s"' % hl) if hl else ''
    tit = F(c, 'Título', L)
    head = '<p class="lc-id">%s%s</p>' % (E(c['ID']), (' · <span%s>%s</span>' % (la, E(tit))) if tit else '')
    b = []
    if tipo == 'TRIVIA':
        for lv in 'PIA':
            q = F(c, lv + ' · Pregunta', L)
            if not q: continue
            ok = (c.get(lv + ' · ✔') or '').strip()
            opts = ''.join('<li>%s</li>' % E(F(c, '%s · %s' % (lv, o), L)) for o in 'ABC')
            ans = F(c, '%s · %s' % (lv, ok), L) if ok in ('A', 'B', 'C') else ''
            exp = F(c, lv + ' · Explicación', L)
            b.append('<div class="lc-q"><p class="lc-lv">%s</p><h3%s>%s</h3><ol class="lc-opts"%s>%s</ol>'
                     '<details><summary>%s</summary><p%s><b>%s.</b> %s</p>%s</details></div>'
                     % (E(T['lv'][lv]), la, E(q), la, opts, E(T['resp']), la, E(ok), E(ans), ('<p%s>%s</p>' % (la, E(exp))) if exp else ''))
        cierre = F(c, 'Cierre (Dato ★ / Remate)', L)
        if cierre: b.append('<p class="lc-star"%s>★ %s</p>' % (la, E(cierre)))
    elif tipo == 'PULSO':
        b.append('<p%s>%s</p>' % (la, E(F(c, 'Situación', L))))
        b.append(effect_html(c.get('Efecto'), L, T))
    elif tipo == 'ENCUENTRO':
        per = F(c, 'Personaje', L) or ((c.get('Personaje') or '').strip() if L in ('MY', 'NA') else '')
        if per: b.append('<p class="lc-per">%s</p>' % E(per))
        b.append('<p%s>%s</p>' % (la, E(F(c, 'Escena', L))))
        eco = F(c, 'Eco emocional', L)
        if eco: b.append('<p class="lc-eco"%s>%s</p>' % (la, E(eco)))
        b.append(effect_html(F(c, 'Efecto', L) or c.get('Efecto'), L, T))
        cierre = F(c, 'Cierre (Dato ★ / Remate)', L)
        if cierre: b.append('<p class="lc-star"%s>%s</p>' % (la, E(cierre)))
    else:  # RETO
        b.append('<h3%s>%s</h3>' % (la, E(F(c, 'Consigna', L))))
        ya = F(c, 'YA LO HAGO', L)
        raw_int = F(c, 'LO INTENTARÉ', L) or (c.get('LO INTENTARÉ') or '').strip()
        mm = re.match(r'^(.*)\s·\s([^·]+)$', raw_int)
        int_txt, int_tok = (mm.group(1).strip(), mm.group(2).strip()) if mm else ('', raw_int)
        if re.match(r'^(Reserva|[+-]\d)', int_txt or 'x') and not mm: int_txt = ''
        rows = ['<li><b>%s</b>%s <span class="lc-fx">%s</span></li>' % (E(T['ya']), (' <span%s>%s</span>' % (la, E(ya))) if ya else '', E(tag(c.get('→ Efecto'), L))),
                '<li><b>%s</b>%s <span class="lc-fx">%s</span></li>' % (E(T['intento']), (' <span%s>%s</span>' % (la, E(int_txt))) if int_txt else '', E(tag(int_tok, L))),
                '<li><b>%s</b> <span class="lc-fx">%s</span></li>' % (E(T['paso']), E(tag(c.get('PASO'), L)))]
        b.append('<ul class="lc-reto">%s</ul>' % ''.join(rows))
        eco = F(c, 'Eco emocional', L)
        if eco: b.append('<p class="lc-eco"%s>%s</p>' % (la, E(eco)))
    return '<article class="lc" id="%s">%s%s</article>' % (EQ(c['ID']), head, ''.join(b))

def build_page(g, L, avail, order):
    chrome = 'EN' if L == 'EN' else 'ES'
    T = TX[chrome]; info = guardian_info(g)
    tpl = rd(('en/fauna/%s.html' if chrome == 'EN' else 'fauna/%s.html') % g['slug'])
    up = '../../' if chrome == 'EN' else '../'           # raíz del sitio
    full = info['full_en'] if chrome == 'EN' else info['full_es']
    terr = info['terr_en'] if chrome == 'EN' else info['terr_es']
    name = g['displayName']; code = g['code']
    hl = XL[L]['lang'] if L in XL else ''
    secs = {t: cards_of(code, t, L) for t in TIPOS}
    n = sum(len(v) for v in secs.values())
    if L in XL:
        title = T['titlex'] % (full, XL[L]['nombre']); desc = T['descx'] % (full, XL[L]['nombre'], terr); h1 = T['h1x'] % (full, XL[L]['nombre'])
    else:
        title = T['title'] % (n, full); desc = T['desc'] % (n, full, terr); h1 = T['h1'] % (n, full)
    url = page_url(g, L)
    # ----- head -----
    head = tpl[:tpl.find('</head>')]
    head = re.sub(r'<title>.*?</title>', '<title>%s</title>' % E(title), head, count=1, flags=re.S)
    head = re.sub(r'(<meta name="description" content=")[^"]*(")', lambda m: m.group(1) + EQ(desc) + m.group(2), head, count=1)
    head = re.sub(r'(<meta property="og:title" content=")[^"]*(")', lambda m: m.group(1) + EQ(title) + m.group(2), head, count=1)
    head = re.sub(r'(<meta property="og:description" content=")[^"]*(")', lambda m: m.group(1) + EQ(desc) + m.group(2), head, count=1)
    head = re.sub(r'<link rel="canonical"[^>]*>', '', head); head = re.sub(r'<link rel="alternate" hreflang="[^"]*"[^>]*>', '', head)
    head = re.sub(r'<script type="application/ld\+json">.*?</script>', '', head, flags=re.S)
    head = re.sub(r'<meta name="robots"[^>]*>', '', head)
    css = re.search(r'<link rel="stylesheet" href="([^"]*assets-lfi/)sitio\.css\?v=[^"]*">', head)
    assert css, 'sin sitio.css en ' + g['slug']
    head = head.replace(css.group(0), css.group(0) + '<link rel="stylesheet" href="%slectura.css?v=__BUILD__">' % css.group(1))
    links = '<meta name="robots" content="max-image-preview:large"><link rel="canonical" href="%s">' % url
    if L in ('ES', 'EN') and 'EN' in avail:
        links += '<link rel="alternate" hreflang="es" href="%s"><link rel="alternate" hreflang="en" href="%s"><link rel="alternate" hreflang="x-default" href="%s">' % (page_url(g, 'ES'), page_url(g, 'EN'), page_url(g, 'ES'))
    home = ORIGIN + ('/en/' if chrome == 'EN' else '/')
    ld = [{"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [
            {"@type": "ListItem", "position": 1, "name": "FAUNA Guardianes", "item": home + 'fauna/'},
            {"@type": "ListItem", "position": 2, "name": T['crumb_cards'], "item": home + 'cartas'},
            {"@type": "ListItem", "position": 3, "name": title.split(' | ')[0], "item": url}]},
          {"@context": "https://schema.org", "@type": "CollectionPage", "name": title.split(' | ')[0], "description": desc, "url": url,
           "inLanguage": {'ES': 'es', 'EN': 'en', 'MY': 'myn', 'NA': 'nah'}[L],
           "isPartOf": {"@type": "WebSite", "name": "La Fábrica Inventiva", "url": ORIGIN + '/'},
           "about": {"@type": "Game", "name": "FAUNA Guardianes", "url": home + 'fauna/'}}]
    links += ''.join('<script type="application/ld+json">%s</script>' % json.dumps(x, ensure_ascii=False) for x in ld)
    head = head.rstrip() + links
    # ----- cuerpo: encabezado y pie de la ficha -----
    body = tpl[tpl.find('</head>'):]
    pre = body[:body.find('<main>')]; post = body[body.find('</main>') + len('</main>'):]
    pre = pre.replace('data-page-type="guardian"', 'data-page-type="cards-read"')
    if chrome == 'EN':
        sw = '<a class="lang-sw" href="../../%s" hreflang="es" lang="es" title="Leer esta página en español">ES</a>' % page_path(g, 'ES')
    else:
        sw = '<a class="lang-sw" href="../%s" hreflang="en" lang="en" title="Read this page in English">EN</a>' % page_path(g, 'EN') if 'EN' in avail else ''
    pre, k = re.subn(r'<a class="lang-sw"[^>]*>[^<]*</a>', lambda m: sw, pre, count=1); assert k == 1
    # ----- contenido -----
    here = os.path.dirname(page_path(g, L))
    rel = lambda p: os.path.relpath(os.path.join(SITE, p), os.path.join(SITE, here)).replace(os.sep, '/')
    loc = lambda p: rel(('en/' if chrome == 'EN' else '') + p)       # página del mismo idioma de navegación
    chips = []
    for l2 in ['ES', 'EN', 'MY', 'NA']:
        if l2 not in avail: continue
        if l2 == L: chips.append('<li aria-current="page"><b>%s</b></li>' % CHIP[l2])
        else: chips.append('<li><a href="%s">%s</a></li>' % (rel(page_path(g, l2)), CHIP[l2]))
    fuentes = loc('docs/fuentes.html')
    estado = (T['estado_x'] if L in XL else T['estado']) % (fuentes, code)
    toc = ''.join('<li><a href="#%s">%s · %d</a></li>' % (TKEY[t], E(TIL[chrome][TKEY[t]][0]), len(secs[t])) for t in TIPOS if secs[t])
    face = ('<img class="gface" style="--g:%s" src="%sassets-lfi/%s" alt="%s" width="136" height="136">' % (info['color'], up, info['face'], EQ(T['retrato'] % name))) if info['face'] else ''
    m = ['<main>',
         '<div class="wrap"><p class="crumbs"><a href="%s">FAUNA Guardianes</a> / <a href="%s">%s</a> / <a href="%s">%s</a></p></div>'
         % (loc('fauna/index.html'), loc('cartas.html'), E(T['crumb_cards']), loc('fauna/%s.html' % g['slug']), E(name)),
         '<section class="sec band" style="--g:%s"><div class="wrap"><p class="eyebrow" style="color:%s">%s</p>%s<h1>%s</h1>'
         % (info['color'], info['color'], E(T['eyebrow'] % n), face, E(h1)),
         '<p class="lead">%s</p><p style="max-width:60ch">%s</p>' % (E(T['terr'] % terr), E(T['intro'])),
         '<div class="row"><a class="btn teja" href="%s?g=%s" data-guardian-code="%s">%s</a><a class="btn alt" href="%s?g=%s" data-guardian-code="%s">%s</a></div>'
         % (loc('consola.html'), code, code, E(T['jugar']), loc('cartas.html'), code, code, E(T['explorador'])),
         '<p class="eyebrow" style="margin-top:1.6rem">%s</p><ul class="chips lc-langs">%s</ul><p class="muted small" style="max-width:60ch">%s</p>' % (E(T['leer_en']), ''.join(chips), estado),
         '<p class="eyebrow" style="margin-top:1.2rem">%s</p><ul class="chips lc-toc">%s</ul>' % (E(T['toc']), toc),
         '</div></section>']
    for i, t in enumerate(TIPOS):
        if not secs[t]: continue
        nm, ds = TIL[chrome][TKEY[t]]
        m.append('<section class="sec lc-sec%s" id="%s" style="--g:%s"><div class="wrap"><p class="eyebrow">%s · %s</p><h2>%s</h2><p class="muted lc-intro">%s</p><div class="lc-list%s">%s</div></div></section>'
                 % (' panel' if i % 2 else '', TKEY[t], info['color'], E(nm), E(T['n'] % len(secs[t])), E(T['sec'][t] % name), E(ds),
                    ' lc-list--wide' if t == 'TRIVIA' else '', ''.join(render_card(c, t, L, T, hl) for c in secs[t])))
    # anterior / siguiente entre los guardianes que tienen este idioma
    i = order.index(g['code']); prev = GSBY[order[i - 1]]; nxt = GSBY[order[(i + 1) % len(order)]]
    m.append('<section class="sec"><div class="wrap"><p class="pn"><a href="%s">← %s</a><a href="%s">%s</a><a href="%s">%s →</a></p><p class="small"><a href="%s">%s</a></p></div></section>'
             % (rel(page_path(prev, L)), E(prev['displayName']), loc('cartas.html'), E(T['todas']), rel(page_path(nxt, L)), E(nxt['displayName']),
                loc('fauna/%s.html' % g['slug']), E(T['volver'] % name)))
    m.append('</main>')
    return head + pre + '\n'.join(m) + post, n

GSBY = {g['code']: g for g in GS}
made = []
for L in ['ES', 'EN', 'MY', 'NA']:
    order = [g['code'] for g in GS if sum(len(cards_of(g['code'], t, L)) for t in TIPOS) >= 40]
    for code in order:
        g = GSBY[code]
        avail = [l for l in ['ES', 'EN', 'MY', 'NA'] if sum(len(cards_of(code, t, l)) for t in TIPOS) >= 40]
        s, n = build_page(g, L, avail, order)
        wr(page_path(g, L), s); made.append((page_path(g, L), L, n))
print('páginas:', len(made), {L: sum(1 for m in made if m[1] == L) for L in ['ES', 'EN', 'MY', 'NA']}, 'cartas:', sum(m[2] for m in made))
