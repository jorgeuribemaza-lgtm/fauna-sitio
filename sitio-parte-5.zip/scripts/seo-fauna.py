# -*- coding: utf-8 -*-
"""FAUNA Guardianes · capa de buscadores V13.12 sobre las páginas que ya existen.
No cambia textos visibles salvo: un renglón de enlaces a la lectura de cartas en cada ficha y en el explorador.
Es idempotente (marca lo que agrega con data-seo / data-lc). Uso: python3 scripts/seo-fauna.py [carpeta del sitio]   (después de scripts/cartas-lectura.py)
"""
import json, io, os, re, html, sys
SITE = sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
rd = lambda p: io.open(os.path.join(SITE, p), encoding='utf-8').read()
def wr(p, s): io.open(os.path.join(SITE, p), 'w', encoding='utf-8', newline='').write(s)
EQ = lambda s: html.escape(s or '', quote=True)
txt = lambda s: re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', ' ', s))).strip()
S = json.loads(rd('data/sitio.json')); ORIGIN = S['siteOrigin'].rstrip('/')
GS = S['guardians']
HAVE = set()
for d in ('cartas', 'en/cartas'):
    if os.path.isdir(os.path.join(SITE, d)):
        HAVE.update(d + '/' + f for f in os.listdir(os.path.join(SITE, d)) if f.endswith('.html'))
def ncards(p): return len(re.findall(r'<article class="lc"', rd(p)))
log = []

def ld(obj): return '<script type="application/ld+json" data-seo="v13-12">%s</script>' % json.dumps(obj, ensure_ascii=False)
def put_ld(s, objs):
    s = re.sub(r'<script type="application/ld\+json" data-seo="v13-12">.*?</script>', '', s, flags=re.S)
    i = s.find('</head>'); return s[:i] + ''.join(ld(o) for o in objs) + s[i:]
def set_title(s, new):
    s, a = re.subn(r'<title>.*?</title>', '<title>%s</title>' % html.escape(new, quote=False), s, count=1, flags=re.S)
    s, b = re.subn(r'(<meta property="og:title" content=")[^"]*(")', lambda m: m.group(1) + EQ(new) + m.group(2), s, count=1)
    assert a == 1 and b == 1; return s
def desc_of(s): return html.unescape(re.search(r'<meta name="description" content="([^"]*)"', s).group(1))
def canon_of(s): return re.search(r'<link rel="canonical" href="([^"]*)"', s).group(1)

ORG = {"@type": "Organization", "name": "La Fábrica Inventiva", "url": ORIGIN + "/", "logo": ORIGIN + "/assets-lfi/logo.jpg",
       "sameAs": ["https://www.instagram.com/lafabricainventiva/"]}

for en in (False, True):
    P = 'en/' if en else ''; home = ORIGIN + ('/en/' if en else '/'); lang = 'en' if en else 'es'
    # ---------- portada ----------
    p = P + 'index.html'; s = rd(p)
    s = re.sub(r'<script type="application/ld\+json">\s*\{"@context": "https://schema.org", "@type": "Organization", "name": "La Fábrica Inventiva"\}\s*</script>', '', s)
    s = set_title(s, 'La Fábrica Inventiva | FAUNA Guardianes, stories and objects' if en else 'La Fábrica Inventiva | FAUNA Guardianes, cuentos y objetos')
    objs = [dict({"@context": "https://schema.org"}, **ORG)]
    if not en:   # WebSite va una sola vez, en la portada raíz: de ahí toma Google el nombre del sitio
        objs.append({"@context": "https://schema.org", "@type": "WebSite", "name": "La Fábrica Inventiva", "alternateName": ["FAUNA Guardianes", "Biblioteca UC"],
                     "url": ORIGIN + "/", "inLanguage": ["es", "en"], "description": desc_of(s), "publisher": {"@type": "Organization", "name": "La Fábrica Inventiva", "url": ORIGIN + "/"}})
    s = put_ld(s, objs)
    wr(p, s); log.append(p + ': título, Organization' + ('' if en else ', WebSite'))
    # ---------- el juego ----------
    p = P + 'fauna/index.html'; s = rd(p)
    s = set_title(s, 'FAUNA Guardianes, a cooperative board game | La Fábrica Inventiva' if en else 'FAUNA Guardianes, juego de mesa cooperativo | La Fábrica Inventiva')
    items = [{"@type": "ListItem", "position": i + 1, "name": None, "url": home + 'fauna/' + g['slug']} for i, g in enumerate(GS)]
    for it, g in zip(items, GS):
        gp = rd(P + 'fauna/%s.html' % g['slug']); it['name'] = txt(re.search(r'<h1[^>]*>(.*?)</h1>', gp, re.S).group(1)) if en else g['fullName']
    s = put_ld(s, [{"@context": "https://schema.org", "@type": "Game", "name": "FAUNA Guardianes", "url": home + 'fauna/', "description": desc_of(s),
                    "genre": "Cooperative board game" if en else "Juego de mesa cooperativo", "inLanguage": lang, "image": ORIGIN + "/assets-lfi/og.jpg",
                    "creator": {"@type": "Organization", "name": "La Fábrica Inventiva", "url": ORIGIN + "/"}},
                   {"@context": "https://schema.org", "@type": "ItemList", "name": "The fifteen Guardians" if en else "Los quince guardianes", "itemListElement": items},
                   {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [
                       {"@type": "ListItem", "position": 1, "name": "La Fábrica Inventiva", "item": home},
                       {"@type": "ListItem", "position": 2, "name": "FAUNA Guardianes", "item": home + 'fauna/'}]}])
    # retratos y villanos: texto alternativo (antes vacío)
    for g in GS:
        s = re.sub(r'(<img\b[^>]*src="[^"]*assets-lfi/g-%s\.webp"[^>]*?)alt=""' % re.escape(g['slug']),
                   lambda m: m.group(1) + 'alt="%s"' % EQ(('Illustrated portrait of %s' if en else 'Retrato ilustrado de %s') % g['displayName']), s)
    for v in ['silentia', 'caloris', 'plastigma', 'devorax']:
        s = re.sub(r'(<img\b[^>]*src="[^"]*assets/villano-%s\.png"[^>]*?)alt=""' % v,
                   lambda m: m.group(1) + 'alt="%s"' % EQ(('Illustration of %s' if en else 'Ilustración de %s') % v.capitalize()), s)
    wr(p, s); log.append(p + ': título, Game, ItemList, migas, alt de retratos y villanos')
    # ---------- fichas de guardián ----------
    for g in GS:
        p = P + 'fauna/%s.html' % g['slug']; s = rd(p)
        name = txt(re.search(r'<h1[^>]*>(.*?)</h1>', s, re.S).group(1))
        if name == g['displayName'] and not en: name = g['fullName']
        s = put_ld(s, [{"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [
            {"@type": "ListItem", "position": 1, "name": "FAUNA Guardianes", "item": home + 'fauna/'},
            {"@type": "ListItem", "position": 2, "name": name, "item": canon_of(s)}]}])
        if 'data-lc="1"' not in s:
            es_p = 'cartas/%s.html' % g['slug']; en_p = 'en/cartas/%s.html' % g['slug']
            my = 'cartas/%s-maya.html' % g['slug']; na = 'cartas/%s-nahuatl.html' % g['slug']
            up = '../../' if en else '../'
            if en:
                parts = ['<a href="../cartas/%s.html">Read all %d cards in full</a>' % (g['slug'], ncards(en_p))] if en_p in HAVE else []
                if my in HAVE: parts.append('<a href="%s%s">in Maya</a>' % (up, my))
                if na in HAVE: parts.append('<a href="%s%s">in Nahuatl</a>' % (up, na))
            else:
                parts = ['<a href="../%s">Leer sus %d cartas completas</a>' % (es_p, ncards(es_p))] if es_p in HAVE else []
                if my in HAVE: parts.append('<a href="../%s">en maya</a>' % my)
                if na in HAVE: parts.append('<a href="../%s">en náhuatl</a>' % na)
            if parts:
                eyebrow = 'Card languages' if en else 'Idiomas de sus cartas'
                i = s.find('<p class="eyebrow">%s</p>' % eyebrow); assert i > 0, p
                j = s.find('</ul>', i); assert j > 0, p
                s = s[:j + 5] + '<p class="small" data-lc="1" style="margin-top:.9rem">' + ' · '.join(parts) + '</p>' + s[j + 5:]
        wr(p, s)
    log.append(P + 'fauna/<15 fichas>: migas y enlace a la lectura de cartas')
    # ---------- explorador ----------
    p = P + 'cartas.html'; s = rd(p)
    if 'data-lc="1"' not in s:
        links = ' · '.join('<a href="./cartas/%s.html" style="color:#E0C987">%s</a>' % (g['slug'], html.escape(g['displayName'])) for g in GS)
        lead = 'To read them in full, Guardian by Guardian: ' if en else 'Para leerlas completas, guardián por guardián: '
        block = '<p data-lc="1" style="max-width:1100px;margin:6px auto 0;padding:0 18px;font:400 13px/1.9 \'Public Sans\',system-ui,sans-serif;color:#C6D3C6">%s%s</p>' % (lead, links)
        i = s.find('<main class="grid" id="grid">'); assert i > 0
        s = s[:i] + block + '\n' + s[i:]
    crumbs = [{"@type": "ListItem", "position": 1, "name": "FAUNA Guardianes", "item": home + 'fauna/'},
              {"@type": "ListItem", "position": 2, "name": "Cards" if en else "Cartas", "item": home + 'cartas'}]
    s = put_ld(s, [{"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": crumbs}])
    wr(p, s); log.append(p + ': enlaces a las 15 lecturas, migas')
    # ---------- antes de pedir: preguntas y respuestas ----------
    p = P + 'ayuda.html'; s = rd(p)
    qa = [(txt(q), txt(a)) for q, a in re.findall(r'<dt[^>]*>(.*?)</dt>\s*<dd[^>]*>(.*?)</dd>', s, re.S)]
    assert len(qa) >= 8, (p, len(qa))
    s = put_ld(s, [{"@context": "https://schema.org", "@type": "FAQPage", "inLanguage": lang, "mainEntity": [
        {"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}} for q, a in qa]}])
    wr(p, s); log.append('%s: FAQPage con %d preguntas' % (p, len(qa)))
    # ---------- cuentos ----------
    p = P + 'docs/cuentos/index.html'; s = rd(p)
    books = []
    for art in re.findall(r'<article class="material cuento">(.*?)</article>', s, re.S):
        t = re.search(r'<strong>(.*?)</strong>', art, re.S); pdf = re.search(r'href="(?:\./|(?:\.\./)+docs/cuentos/)([^"]+\.pdf)"', art)
        d = re.search(r'</strong>\s*<span>(.*?)</span>', art, re.S); n = re.search(r'<span class="peso">(\d+)\s', art)
        if not (t and pdf): continue
        b = {"@type": "Book", "name": txt(t.group(1)), "url": ORIGIN + '/docs/cuentos/' + pdf.group(1), "inLanguage": "es", "bookFormat": "https://schema.org/EBook",
             "isAccessibleForFree": True, "publisher": {"@type": "Organization", "name": "La Fábrica Inventiva", "url": ORIGIN + "/"}}
        if d: b["description"] = txt(d.group(1))
        if n: b["numberOfPages"] = int(n.group(1))
        books.append(b)
    assert len(books) >= 10, (p, len(books))
    s = put_ld(s, [{"@context": "https://schema.org", "@type": "ItemList", "name": txt(re.search(r'<title>(.*?)</title>', s, re.S).group(1)).split(' | ')[0],
                    "itemListElement": [{"@type": "ListItem", "position": i + 1, "item": b} for i, b in enumerate(books)]}])
    wr(p, s); log.append('%s: ItemList con %d cuentos' % (p, len(books)))
    # ---------- portadas de cuentos en la portada: texto alternativo ----------
    p = P + 'index.html'; s = rd(p)
    for g in GS:
        s = re.sub(r'(<img\b[^>]*src="[^"]*docs/cuentos/portada_%s\.jpg"[^>]*?)alt=""' % re.escape(g['displayName'].lower().replace('á', 'a')),
                   lambda m: m.group(1) + 'alt="%s"' % EQ(('Cover of the story of %s' if en else 'Portada del cuento de %s') % g['displayName']), s)
    wr(p, s)

# ---------- permiso de imagen grande en todas las páginas públicas ----------
n = 0
for root, ds, fs in os.walk(SITE):
    for f in fs:
        if not f.endswith('.html'): continue
        p = os.path.relpath(os.path.join(root, f), SITE); s = rd(p)
        if re.search(r'<meta name="robots"', s): continue
        m = re.search(r'<meta name="description"[^>]*>', s)
        if not m: continue
        s = s[:m.end()] + '<meta name="robots" content="max-image-preview:large">' + s[m.end():]; wr(p, s); n += 1
log.append('permiso de imagen grande en %d páginas públicas' % n)
print('\n'.join(log))
