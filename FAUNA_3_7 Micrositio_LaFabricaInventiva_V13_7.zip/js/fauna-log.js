/* ============================================================
   FAUNA GUARDIANES · WANHA — Telemetría por tester
   Envía eventos al mismo Cloudflare Worker del original.
   Contrato /collect: { events:[ {appVersion,event,ts,epochMs,
     deviceId,sessionId,testerCode,playerCount,activeGuardians,
     guardian_score,villain_score,payload} ] }
   Marca appVersion:"wanha" para separar del original en la misma D1.
   ============================================================ */
(function () {
"use strict";

var META = document.querySelector('meta[name="fauna-log-endpoint"]');
var ENDPOINT = META ? META.getAttribute("content") : "";
var APP_VERSION = "wanha";
var FLUSH_MS = 4000;      // envío por lotes
var MAX_BATCH = 25;

/* ---- ids persistentes / de sesión ---- */
function uuid(){return (Date.now().toString(36)+Math.random().toString(36).slice(2,10));}
function deviceId(){
  var k="fauna_device_id",v;
  try{v=localStorage.getItem(k);if(!v){v=uuid();localStorage.setItem(k,v);}}catch(e){v=v||uuid();}
  return v;
}
function testerCode(){
  try{
    var u=new URL(window.location.href), t=u.searchParams.get("tester");
    if(t){try{sessionStorage.setItem("fauna_tester",t);}catch(e){} return t;}
    return sessionStorage.getItem("fauna_tester")||null;
  }catch(e){return null;}
}

var DEVICE=deviceId(), SESSION=uuid(), TESTER=testerCode();
var queue=[], timer=null;

/* contexto mutable que el simulador actualiza */
var ctx={playerCount:null,activeGuardians:null,guardianScore:null,villainScore:null};
function setContext(o){if(!o)return;
  if("playerCount"in o)ctx.playerCount=o.playerCount;
  if("activeGuardians"in o)ctx.activeGuardians=o.activeGuardians;
  if("guardianScore"in o)ctx.guardianScore=o.guardianScore;
  if("villainScore"in o)ctx.villainScore=o.villainScore;
}

function log(event,payload){
  if(!event)return;
  var now=new Date();
  queue.push({
    appVersion:APP_VERSION,
    edicion:"wanha",
    event:String(event),
    ts:now.toISOString(),
    epochMs:now.getTime(),
    deviceId:DEVICE,
    sessionId:SESSION,
    testerCode:TESTER,
    playerCount:ctx.playerCount,
    activeGuardians:ctx.activeGuardians,
    guardian_score:ctx.guardianScore,
    villain_score:ctx.villainScore,
    scores:{g:ctx.guardianScore,v:ctx.villainScore},
    payload:payload||{}
  });
  if(queue.length>=MAX_BATCH)flush();
  else if(!timer)timer=setTimeout(flush,FLUSH_MS);
}

function flush(useBeacon){
  if(timer){clearTimeout(timer);timer=null;}
  if(!ENDPOINT||!queue.length)return;
  var batch=queue.splice(0,queue.length);
  var body=JSON.stringify({events:batch});
  try{
    if(useBeacon&&navigator.sendBeacon){
      navigator.sendBeacon(ENDPOINT,new Blob([body],{type:"application/json"}));
      return;
    }
    fetch(ENDPOINT,{method:"POST",headers:{"Content-Type":"application/json"},body:body,keepalive:true})
      .catch(function(){/* silencioso: nunca romper el juego */});
  }catch(e){/* noop */}
}

/* vaciar al ocultar/cerrar */
window.addEventListener("visibilitychange",function(){if(document.visibilityState==="hidden"){log("session_hidden");flush(true);}});
window.addEventListener("pagehide",function(){log("session_end");flush(true);});

/* API pública mínima */
window.FaunaLog={ log:log, setContext:setContext, flush:flush,
  info:function(){return {endpoint:ENDPOINT,tester:TESTER,session:SESSION,device:DEVICE};} };

/* evento de arranque */
log("session_start",{ua:navigator.userAgent,lang:navigator.language,ref:document.referrer||null});
})();
