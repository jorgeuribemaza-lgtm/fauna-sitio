/* La Fábrica Inventiva · comportamiento de las páginas del sitio (V12)
   Requiere: assets-lfi/sitio-data.js (generado) y assets-lfi/lfi-core.js, cargados antes.
   Pliego V11: COM-01/02, CTX-01, FOR-01/02, QUI-01, PIE-01/02/03, PAQ-01, TAB-01, ENC-01, ALI-01, CAU-01, MIK-01, MED-01. */
(function () {
'use strict';
var LFI = window.LFI, D = window.LFI_DATA;
if (!LFI || !D) return;
var doc = document;
function $(s, r) { return (r || doc).querySelector(s); }
function $$(s, r) { return Array.prototype.slice.call((r || doc).querySelectorAll(s)); }
function g(code) { return LFI.guardianByCode[code]; }
function tpl(s, o) { return String(s).replace(/\{(\w+)\}/g, function (_, k) { return o[k] != null ? o[k] : ''; }); }

/* ===================== FORMULARIOS (FOR-01/02 · PIE · PAQ · TAB · ENC · ALI) ===================== */
var CLOSE = '¿Me confirman el total con envío?';

function readOptional(form, sel, max, label, errs, lines) {
  var el = $(sel, form); if (!el) return;
  var r = LFI.validate.optionalText(el.value, max);
  if (!r.ok) errs.push([el, r]); else if (r.value) lines.push(label + ': ' + r.value + '.');
}

/* Configuración de un formulario de producto */
function productState(form) {
  var pid = form.getAttribute('data-product'), P = D.products[pid];
  var sels = $$('select.g-select', form);
  var codes = sels.map(function (s) { return LFI.normCode(s.value); });
  var qEl = $('#f-cant', form);
  var q = LFI.validate.quantity(qEl ? qEl.value : '1', P.priceMXN);
  return { pid: pid, P: P, sels: sels, codes: codes, qEl: qEl, q: q };
}

function validateProduct(form, st, strict) {
  var errs = [];
  st.sels.forEach(function (s, i) {
    var c = st.codes[i];
    if (!c) errs.push([s, { code: 'invalid_code', msg: 'Elige un guardián de la lista.' }]);
    else if (i > 0 && st.codes.indexOf(c) < i) errs.push([s, { code: 'duplicate_guardian', msg: 'Tu mesa necesita dos guardianes distintos.' }]);
  });
  if (!st.q.ok) errs.push([st.qEl, st.q]);
  var city = $('#f-ciudad', form), rc = LFI.validate.city(city ? city.value : '');
  if (!rc.ok && (strict || (city && city.value))) errs.push([city, rc]);
  var lines = [];
  readOptional(form, '#f-fecha', 100, 'Ocasión', errs, lines);
  readOptional(form, '#f-ded', 120, 'Dedicatoria para', errs, lines);
  return { errs: errs, city: rc.ok ? rc.value : '', optional: lines };
}

function hasVita(codes) { return codes.indexOf('VITA') >= 0; }

function productMessage(st, v) {
  var P = st.P, q = st.q.ok ? st.q.value : 1, sub = P.priceMXN * q, L = [];
  var city = v.city || '{tu ciudad}';
  if (st.pid === 'primera_partida') {
    L.push('Hola, quiero pedir una Primera partida de FAUNA Guardianes.');
    L.push('Primera partida: tablero + 2 guardianes · ' + LFI.money(P.priceMXN) + ' por conjunto.');
    L.push('Guardián 1: ' + LFI.nameOf(st.codes[0]) + '.');
    L.push('Guardián 2: ' + LFI.nameOf(st.codes[1]) + '.');
    L.push('Cantidad: ' + q + '.');
    L.push('Subtotal de piezas: ' + LFI.money(sub) + '. Envío por consultar.');
    L.push('Cada guardián con su figura, su villano, sus 80 cartas, su cuento y su portavasos.');
  } else if (st.pid === 'paquete_guardian') {
    L.push('Hola, quiero pedir un Paquete de guardián de FAUNA Guardianes.');
    L.push('Guardián: ' + LFI.nameOf(st.codes[0]) + '.');
    L.push('Cantidad: ' + q + '.');
    L.push('Precio unitario: ' + LFI.money(P.priceMXN) + '.');
    L.push('Subtotal de piezas: ' + LFI.money(sub) + '. Envío por consultar.');
    L.push('Con su figura, su villano, sus 80 cartas, su cuento y su portavasos.');
  } else {
    L.push('Hola, quiero pedir un Conjunto de tablero de FAUNA Guardianes.');
    L.push('Cantidad: ' + q + '.');
    L.push('Precio unitario: ' + LFI.money(P.priceMXN) + '.');
    L.push('Subtotal de piezas: ' + LFI.money(sub) + '. Envío por consultar.');
  }
  L.push('Ciudad: ' + city + '.');
  v.optional.forEach(function (x) { L.push(x); });
  L.push(CLOSE);
  return L.join('\n');
}

function miniHTML(form, x) {
  var img = x.portrait ? '<img src="' + (form.getAttribute('data-root') || '') + 'assets-lfi/g-' + x.slug + '.webp" alt="">' : '<i aria-hidden="true"></i>';
  return '<span class="lfi-mini" style="--g:' + x.color + '">' + img + '<b></b></span>';
}
function paintProduct(form, st) {
  var q = st.q.ok ? st.q.value : null;
  var sum = $('.lfi-summary', form);
  if (sum) {
    var h = '';
    if (st.pid === 'primera_partida') {
      h += '<p class="eyebrow">Tu Primera partida</p><div class="lfi-pair">' + st.codes.map(function (c) {
        var x = g(c); if (!x) return '';
        return miniHTML(form, x);
      }).join('') + '</div><p>1 tablero + 2 guardianes · 160 cartas de los guardianes elegidos</p>';
    } else if (st.pid === 'paquete_guardian') {
      var x = g(st.codes[0]);
      h += '<p class="eyebrow">Tu Paquete de guardián</p><div class="lfi-pair">' + (x ? miniHTML(form, x) : '') + '</div><p>Un guardián, un villano, sus 80 cartas y un portavasos de madera grabado.</p>';
    } else {
      h += '<p class="eyebrow">Tu Conjunto de tablero</p><p>Tablero, reglamento, dados y fichas.</p>';
    }
    h += '<p class="lfi-qty"></p><p class="lfi-sub"></p>';
    sum.innerHTML = h;
    var names = $$('.lfi-mini b', sum);
    st.codes.forEach(function (c, i) { if (names[i]) names[i].textContent = LFI.nameOf(c); });
    $('.lfi-qty', sum).textContent = 'Cantidad: ' + (q || '—');
    $('.lfi-sub', sum).textContent = q ? 'Subtotal de piezas: ' + LFI.money(st.P.priceMXN * q) + '. Envío por consultar.' : 'Escribe una cantidad entera para ver el subtotal.';
  }
  var story = $('.lfi-story', form);
  if (story) {
    story.innerHTML = '';
    st.codes.forEach(function (c) { if (!c) return; var p = doc.createElement('p'); p.textContent = LFI.storyLine(c); story.appendChild(p); });
  }
  var vita = $('.lfi-vita', form);
  if (vita) vita.hidden = !hasVita(st.codes);
  var btn = $('.wa', form);
  if (btn) {
    if (st.pid === 'primera_partida') btn.textContent = 'Pedir mi Primera partida';
    else if (st.pid === 'paquete_guardian') btn.textContent = 'Pedir a ' + LFI.nameOf(st.codes[0]);
  }
  // deshabilitar el guardián del otro selector
  if (st.sels.length === 2) st.sels.forEach(function (s, i) {
    var other = st.codes[1 - i];
    $$('option', s).forEach(function (o) { o.disabled = (o.value === other); });
  });
}

function requestModeProduct(st) { return 'order_inquiry'; }

/* --- formulario genérico (encargos, aliados) --- */
function validateGeneric(form, strict) {
  var errs = [], lines = [];
  $$('[data-k]', form).forEach(function (el) {
    var label = el.getAttribute('data-k');
    var req = el.getAttribute('data-req'), max = +(el.getAttribute('data-max') || 120);
    var r;
    if (req) {
      var mm = req.split(','), msg = el.getAttribute('data-msg') || 'Este campo es necesario.';
      r = LFI.validate.requiredText(el.value, +mm[0], +mm[1], msg);
      if (!r.ok && !strict && !el.value) r = { ok: true, value: '' };
    } else if (el.tagName === 'SELECT') {
      var okv = $$('option', el).map(function (o) { return o.value; });
      r = okv.indexOf(el.value) >= 0 ? { ok: true, value: el.value } : { ok: false, code: 'invalid_code', msg: 'Elige una opción de la lista.' };
    } else {
      r = LFI.validate.optionalText(el.value, max);
    }
    if (!r.ok) errs.push([el, r]); else if (r.value) lines.push(label + ': ' + r.value);
  });
  return { errs: errs, lines: lines };
}
function genericMessage(form, v) {
  var L = [form.getAttribute('data-intro')].concat(v.lines);
  var o = form.getAttribute('data-outro'); if (o) L.push(o);
  return L.join('\n');
}
function requestModeGeneric(form) {
  var m = form.getAttribute('data-request-mode') || 'general';
  if (m === 'alliance') { var via = $('#a-via', form); return via && via.value === 'Juegos para mi escuela' ? 'school_inquiry' : 'alliance_inquiry'; }
  return m;
}

/* --- cableado común --- */
function wireForm(form) {
  var isProduct = form.hasAttribute('data-product');
  var fid = form.getAttribute('data-form-id') || (isProduct ? form.getAttribute('data-product') : 'form');
  var msgEl = $('.msg', form), okEl = $('.ok', form), lock = false;
  var nojs = $('.lfi-nojs', form); if (nojs) nojs.hidden = true;

  function evaluate(strict) {
    if (isProduct) { var st = productState(form), v = validateProduct(form, st, strict); return { st: st, v: v, errs: v.errs, msg: productMessage(st, v) }; }
    var vg = validateGeneric(form, strict); return { v: vg, errs: vg.errs, msg: genericMessage(form, vg) };
  }
  function showErrors(errs, focus) {
    $$('[aria-invalid="true"]', form).forEach(function (el) { LFI.fieldError(el, null); });
    errs.forEach(function (e) { LFI.fieldError(e[0], e[1].msg); });
    if (focus && errs[0] && errs[0][0]) errs[0][0].focus();
  }
  function refresh(ev) {
    var r = evaluate(false);
    if (isProduct) paintProduct(form, r.st);
    msgEl.textContent = r.msg;
    // limpiar errores ya corregidos; mostrar límites excedidos al escribir o pegar
    var target = ev && ev.target;
    if (target) {
      var mine = r.errs.filter(function (e) { return e[0] === target; })[0];
      if (mine && (target.getAttribute('aria-invalid') === 'true' || mine[1].code === 'too_long' || mine[1].code === 'invalid_text' || mine[1].code === 'duplicate_guardian')) LFI.fieldError(target, mine[1].msg);
      else if (!mine) LFI.fieldError(target, null);
    }
    return r;
  }
  function attempt(action) {
    if (lock) return null;
    var r = evaluate(true);
    if (r.errs.length) {
      showErrors(r.errs, true);
      LFI.track('formulario_error', { form_id: fid, action: action,
        fields: r.errs.map(function (e) { return e[0].id || ''; }),
        error_codes: r.errs.map(function (e) { return e[1].code; }) });
      if (okEl) okEl.textContent = '';
      return null;
    }
    showErrors([], false);
    msgEl.textContent = r.msg;
    lock = true; setTimeout(function () { lock = false; }, 1000);
    return r;
  }
  function trackParams(r) {
    if (isProduct) {
      var st = r.st;
      return { form_id: fid, product_id: st.pid, request_mode: requestModeProduct(st),
        guardian_codes: st.codes.filter(Boolean), quantity: st.q.value, subtotal_mxn: st.P.priceMXN * st.q.value };
    }
    return { form_id: fid, product_id: null, request_mode: requestModeGeneric(form), guardian_codes: [], quantity: null, subtotal_mxn: null };
  }

  form.addEventListener('input', refresh);
  form.addEventListener('change', function (ev) {
    var r = refresh(ev);
    if (isProduct && r.st) {
      var st = r.st;
      if (st.pid === 'primera_partida' && st.codes[0] && st.codes[1] && st.codes[0] !== st.codes[1]) LFI.firstParty.save(st.codes[0], st.codes[1]);
      if (st.pid === 'paquete_guardian' && st.codes[0] && ev.target.classList.contains('g-select')) LFI.guardianContext.set(st.codes[0]);
      if (ev.target.classList.contains('g-select')) LFI.track('guardian_seleccionado', { guardian_code: st.codes[0], guardian_codes: st.codes.slice(), context: st.pid === 'primera_partida' ? 'first_game' : 'pack', selection_source: 'select' });
      if (st.pid === 'primera_partida' && st.q.ok && st.codes[0] !== st.codes[1]) LFI.track('configurador_cambiado', { product_id: 'primera_partida', guardian_codes: st.codes.slice(), quantity: st.q.value, subtotal_mxn: st.P.priceMXN * st.q.value, request_mode: requestModeProduct(st) });
    }
  });
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var r = attempt('whatsapp'); if (!r) return;
    var p = trackParams(r); p.channel = 'whatsapp'; p.source_component = 'form';
    LFI.track('consulta_iniciada', p);
    window.location.href = LFI.waURL(r.msg);
  });
  var copy = $('.copy', form);
  if (copy) copy.addEventListener('click', function () {
    var r = attempt('copy'); if (!r) return;
    var p = trackParams(r);
    function fb() {
      var range = doc.createRange(); range.selectNodeContents(msgEl);
      var s = window.getSelection(); s.removeAllRanges(); s.addRange(range);
      okEl.textContent = 'Mensaje seleccionado: cópialo y pégalo en WhatsApp.';
    }
    try {
      navigator.clipboard.writeText(r.msg).then(function () {
        okEl.textContent = 'Mensaje copiado. Pégalo en WhatsApp.';
        LFI.track('mensaje_copiado', { form_id: p.form_id, product_id: p.product_id, request_mode: p.request_mode });
      }, fb);
    } catch (e) { fb(); }
  });
  refresh();
}

/* Inicializa selectores de producto según CTX-01 / PIE-01 */
function initProductSelection(form) {
  var pid = form.getAttribute('data-product'), sels = $$('select.g-select', form);
  if (pid === 'primera_partida' && sels.length === 2) {
    var pair = LFI.firstParty.resolve();
    sels[0].value = pair.g1; sels[1].value = pair.g2;
    if (pair.repeated) { var n = $('.lfi-repeated', form); if (n) { n.hidden = false; n.textContent = LFI.firstParty.repeatedMessage; } }
  } else if (pid === 'paquete_guardian' && sels.length === 1) {
    sels[0].value = LFI.guardianContext.resolve(D.defaults.singleGuardian);
  }
}

$$('form[data-product]').forEach(function (f) { initProductSelection(f); wireForm(f); });
$$('form[data-intro]').forEach(wireForm);

/* ===================== TRIVIAS DE MUESTRA (QUI-01) ===================== */
var qSeq = 0;
$$('.quiz').forEach(function (q) {
  var data = JSON.parse($('script', q).textContent), i = Math.floor(Math.random() * data.length);
  var shownObs = null, current = null;
  function show() {
    var c = data[i % data.length], box = $('.q-o', q), x = $('.q-x', q);
    current = { c: c, inst: 'q' + (++qSeq) + '-' + Date.now().toString(36), answered: false, seen: false };
    $('.q-g', q).textContent = c.g; $('.q-g', q).style.color = c.c; $('.q-q', q).textContent = c.q;
    box.innerHTML = ''; x.hidden = true;
    var opts = LFI.shuffleOptions([{ sourceKey: 'A', text: c.A }, { sourceKey: 'B', text: c.B }, { sourceKey: 'C', text: c.C }]);
    opts.forEach(function (o, pos) {
      var b = doc.createElement('button'); b.type = 'button'; b.className = 'opt'; b.textContent = o.text; b.setAttribute('data-k', o.sourceKey);
      b.addEventListener('click', function () {
        if (current.answered) return; current.answered = true;
        $$('button', box).forEach(function (z) { z.disabled = true; if (z.getAttribute('data-k') === c.ok) z.classList.add('ok'); });
        var right = o.sourceKey === c.ok; if (!right) b.classList.add('no');
        x.hidden = false; $('b', x).textContent = right ? '¡Eso es! ' : 'Casi. '; $('span', x).textContent = c.x;
        LFI.track('trivia_respondida', { question_instance_id: current.inst, card_id: c.id || null, level: c.lv || 'P', selected_source_key: o.sourceKey, selected_position: pos + 1, correct: right, surface: 'sample', langs: ['ES'] });
      });
      box.appendChild(b);
    });
    observeShown();
  }
  function observeShown() {
    var cur = current;
    function fire() { if (cur.seen) return; cur.seen = true; LFI.track('trivia_mostrada', { question_instance_id: cur.inst, card_id: cur.c.id || null, level: cur.c.lv || 'P', surface: 'sample', guardian_code: cur.c.code || null, langs: ['ES'] }); }
    if (!('IntersectionObserver' in window)) return fire();
    if (shownObs) shownObs.disconnect();
    shownObs = new IntersectionObserver(function (en) { en.forEach(function (e) { if (e.isIntersecting) { fire(); shownObs.disconnect(); } }); });
    shownObs.observe(q);
  }
  $('.q-n', q).addEventListener('click', function () { i++; show(); });
  show();
});

/* ===================== CAJÓN DE SORPRESAS (sin cambios de contenido) ===================== */
$$('.cajon').forEach(function (c) {
  var data = JSON.parse($('script', c).textContent), last = -1, out = $('.out', c);
  $('button', c).addEventListener('click', function () {
    var i; do { i = Math.floor(Math.random() * data.length); } while (i === last && data.length > 1); last = i;
    var d = data[i]; out.hidden = false;
    $('.eyebrow', out).textContent = d.t; $('p', out).textContent = d.x;
    var a = $('a', out); if (d.h) { a.hidden = false; a.href = d.h; a.textContent = d.l; } else { a.hidden = true; }
    $('button', c).textContent = 'Abrir otro cajón';
  });
});

/* ===================== HUELLAS DE MIKA (MIK-01) ===================== */
function paintPaws() {
  var a = LFI.paws.read();
  $$('.pawcount').forEach(function (e) { e.textContent = a.length; });
  $$('.paw').forEach(function (p) { if (a.indexOf(p.getAttribute('data-paw')) > -1) p.classList.add('found'); });
  $$('.pass li').forEach(function (li) { li.classList.toggle('on', a.indexOf(li.getAttribute('data-p')) > -1); });
  var rw = $('#mika-recompensa'); if (rw) rw.hidden = a.length < LFI.paws.total;
  var storeNote = $('.lfi-paw-storage');
  if (storeNote) {
    if (LFI.paws.mode === 'session') { storeNote.hidden = false; storeNote.textContent = 'Esta vez las huellas se guardarán solo mientras esta ventana siga abierta.'; }
    else if (LFI.paws.mode === 'memory') { storeNote.hidden = false; storeNote.innerHTML = 'Este navegador no puede guardar las huellas entre páginas. La hoja de Mika también está <a href="' + (storeNote.getAttribute('data-sheet') || 'docs/recompensa-mika.html') + '">aquí</a>.'; }
  }
}
$$('.paw').forEach(function (p) {
  p.setAttribute('aria-label', 'Encontrar una huella de Mika');
  p.addEventListener('click', function () {
    var k = p.getAttribute('data-paw'), r = LFI.paws.add(k);
    var n = doc.getElementById('pn-' + k); if (n) n.hidden = false;
    p.classList.add('found'); paintPaws();
    if (r.completedNow) {
      var live = doc.createElement('p'); live.className = 'lfi-note'; live.setAttribute('role', 'status');
      var root = p.getAttribute('data-root') || (location.pathname.indexOf('/fauna/') >= 0 || location.pathname.indexOf('/pieza/') >= 0 || location.pathname.indexOf('/docs/') >= 0 ? '../' : '');
      live.innerHTML = 'Encontraste las ocho. Mika te estaba esperando. <a href="' + root + 'el-taller.html#mika-recompensa">Abrir su secreto</a>';
      (p.closest('.pawline') || p.parentNode).appendChild(live);
    }
  });
});
paintPaws();

/* ===================== COMPROMISOS (CAU-01) ===================== */
(function () {
  var K = 'lfi_compromisos', valid = D.commitmentGuardianCodes, total = valid.length;
  function read() {
    var o = LFI.storage.getJSON(K); var out = {};
    if (!o || typeof o !== 'object' || Array.isArray(o)) return out;
    Object.keys(o).forEach(function (k) { if (valid.indexOf(k) >= 0 && (o[k] === 'ya' || o[k] === 'voy')) out[k] = o[k]; });
    return out;
  }
  function count(o) { return Object.keys(o).length; }
  function paint() {
    var o = read();
    $$('.pledge li').forEach(function (li) {
      var k = li.getAttribute('data-c');
      $$('.pl', li).forEach(function (b) { b.setAttribute('aria-pressed', o[k] === b.getAttribute('data-v') ? 'true' : 'false'); });
    });
    $$('.plcount').forEach(function (e) { e.textContent = count(o); });
    $$('.pltotal').forEach(function (e) { e.textContent = total; });
  }
  $$('.pl').forEach(function (b) {
    b.addEventListener('click', function () {
      var o = read(), k = b.closest('li').getAttribute('data-c'), v = b.getAttribute('data-v');
      if (valid.indexOf(k) < 0) return;
      if (o[k] === v) delete o[k]; else o[k] = v;
      LFI.storage.setJSON(K, o); paint();
      LFI.track('compromiso_cambiado', { guardian_code: k, value: o[k] || 'none', completed_count: count(o) });
    });
  });
  if ($('.pledge')) paint();
})();

/* ===================== MEDICIÓN (MED-01) ===================== */
/* contador visible de visitantes (pie de página) */
$$('[data-visitas]').forEach(function (el) {
  LFI.visitorCount(function (n) { var b = $('b', el); if (b) b.textContent = n.toLocaleString('es-MX'); el.hidden = false; });
});

function onceVisible(el, cb) {
  if (!el) return;
  if (!('IntersectionObserver' in window)) return;
  var t = null, done = false;
  var io = new IntersectionObserver(function (en) {
    en.forEach(function (e) {
      if (done) return;
      if (e.isIntersecting && e.intersectionRatio >= 0.5) { t = setTimeout(function () { done = true; io.disconnect(); cb(); }, 1000); }
      else if (t) { clearTimeout(t); t = null; }
    });
  }, { threshold: [0, 0.5, 1] });
  io.observe(el);
}
var hist = $('#historia-marker'); onceVisible(hist, function () { LFI.track('historia_vista', { section_id: 'historia' }); });
$$('[data-product-view]').forEach(function (el) {
  var pid = el.getAttribute('data-product-view'), P = D.products[pid]; if (!P) return;
  onceVisible(el, function () { LFI.track('producto_visto', { product_id: pid, unit_price_mxn: P.priceMXN, currency: 'MXN' }); });
});

doc.addEventListener('click', function (ev) {
  var a = ev.target.closest && ev.target.closest('a'); if (!a) return;
  var href = a.getAttribute('href') || '';
  if (a.hasAttribute('data-audience')) LFI.track('puerta_elegida', { audience: a.getAttribute('data-audience'), destination_path: href.split('#')[0].split('?')[0] });
  if (a.hasAttribute('data-guardian-code')) LFI.track('guardian_seleccionado', { guardian_code: LFI.normCode(a.getAttribute('data-guardian-code')), context: 'profile', selection_source: 'click' });
  if (a.hasAttribute('data-source-id')) LFI.track('fuente_abierta', { source_id: a.getAttribute('data-source-id'), card_id: a.getAttribute('data-card-id') || null, guardian_code: a.getAttribute('data-guardian') || null, review_kind: a.getAttribute('data-review-kind') || 'science' });
  if (a.hasAttribute('data-teacher-pack')) LFI.track('paquete_docente_abierto', { source_component: a.getAttribute('data-teacher-pack'), resource_id: 'teacher_pack' });
  if (a.hasAttribute('data-reward-open')) LFI.track('recompensa_abierta', { reward_id: 'mika_sheet', source_component: 'mika_reward' });
  if (/\.pdf($|\?)/i.test(href)) {
    var m = href.match(/([^\/]+)\.pdf/i), id = m ? m[1] : 'pdf';
    var type = /Cuento/i.test(id) ? 'story' : /Reglamento/i.test(id) ? 'rules' : /Tablero/i.test(id) ? 'board' : /Docente/i.test(id) ? 'teacher_pack' : 'rules';
    LFI.track('recurso_descarga_iniciada', { resource_id: id, resource_type: type, guardian_code: a.getAttribute('data-guardian') || null });
  }
  if (/^https:\/\/wa\.me\//.test(href) && !a.closest('form')) LFI.track('consulta_iniciada', { channel: 'whatsapp', form_id: null, product_id: null, request_mode: 'general', guardian_codes: [], quantity: null, subtotal_mxn: null, source_component: a.getAttribute('data-source') || 'link' });
}, true);
})();
