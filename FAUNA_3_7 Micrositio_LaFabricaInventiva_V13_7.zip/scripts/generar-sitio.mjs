#!/usr/bin/env node
/* La Fábrica Inventiva · generador previo a publicar (DAT-01)
   Uso:   node scripts/generar-sitio.mjs            (desde la carpeta del sitio)
   Opcional: LFI_APELLIDO_PRIVADO="..." node scripts/generar-sitio.mjs
             → falla si ese texto aparece en algún archivo servido (no lo imprime).
   Qué hace:
   1) Valida data/sitio.json contra data/cartas.json y el HTML.
   2) Escribe assets-lfi/sitio-data.js (window.LFI_DATA) con un buildId nuevo.
   3) Rellena en el HTML los marcadores data-bind (precios y conteos) y la versión ?v= de los recursos.
   4) Busca frases prohibidas por el pliego (promesas de fecha, cifras viejas, errores corregidos).
   Si algo falla, no publica nada y termina con código 1. */
import fs from 'node:fs';
import path from 'node:path';

const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const rd = (p) => fs.readFileSync(path.join(ROOT, p), 'utf8');
const errors = [];
const fail = (m) => errors.push(m);

const S = JSON.parse(rd('data/sitio.json'));
const C = JSON.parse(rd('data/cartas.json'));

/* ---------- 1. validaciones ---------- */
const ids = new Set();
for (const c of C.cartas) { if (ids.has(c.ID)) fail(`ID repetido: ${c.ID}`); ids.add(c.ID); }
if (C.total !== C.cartas.length) fail(`total=${C.total} pero hay ${C.cartas.length} cartas`);
const codes = S.guardians.map((g) => g.code);
const deckCodes = C.guardianes.map((g) => g.code);
/* V13.7: el mazo puede tener guardianes que el portal aún no presenta (ÁMBAR, BALEY, CIMA, INIA, CRUM).
   Se exige que cada guardián del portal exista en el mazo y en el mismo orden; los demás solo se avisan. */
const faltan = codes.filter((c) => !deckCodes.includes(c));
if (faltan.length) fail('Guardianes de sitio.json que no existen en data/cartas.json: ' + faltan.join(', '));
if (deckCodes.filter((c) => codes.includes(c)).join() !== codes.join()) fail('Los guardianes de sitio.json no siguen el orden de data/cartas.json');
const sinFicha = deckCodes.filter((c) => !codes.includes(c));
if (sinFicha.length) console.warn('Aviso: guardianes del mazo sin ficha en el portal (sitio.json): ' + sinFicha.join(', '));
for (const g of S.guardians) {
  const n = C.cartas.filter((c) => c['Guardián'] === g.code).length;
  if (n !== S.cardsPerGuardian) fail(`${g.code} tiene ${n} cartas (se esperaban ${S.cardsPerGuardian})`);
  if (g.storyStatus === 'publicado' && (!g.storyUrl || !fs.existsSync(path.join(ROOT, g.storyUrl)))) fail(`Cuento publicado sin archivo: ${g.code}`);
  if (g.storyStatus !== 'publicado' && g.storyUrl) fail(`Cuento pendiente con URL: ${g.code}`);
}
for (const c of C.cartas) if (!deckCodes.includes(c['Guardián'])) fail(`Carta ${c.ID} con guardián inexistente`);
for (const [k, p] of Object.entries(S.products)) if (!Number.isInteger(p.priceMXN) || p.priceMXN <= 0) fail(`Precio no entero: ${k}`);
const cm = S.commitmentGuardianCodes;
if (new Set(cm).size !== cm.length) fail('Compromiso duplicado');
if (cm.some((c) => !codes.includes(c))) fail('Compromiso con código inválido');
const causa = rd('causa.html');
const causaCodes = [...causa.matchAll(/data-c="([A-Z]+)"/g)].map((m) => m[1]);
if (causaCodes.join() !== cm.join()) fail('causa.html no tiene exactamente los compromisos del registro');
if (new Set(S.pawIds).size !== 8) fail('Las huellas de Mika deben ser 8 IDs únicos');
for (const id of Object.keys(C.revision_bloqueos || {})) if (!ids.has(id)) fail(`Bloqueo para carta inexistente: ${id}`);

/* ---------- 2. sitio-data.js ---------- */
const d = new Date();
const pad = (n) => String(n).padStart(2, '0');
const buildId = `${d.getUTCFullYear()}${pad(d.getUTCMonth() + 1)}${pad(d.getUTCDate())}${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}`;
const out = { ...S, buildId };
delete out._comment;

/* ---------- 3. HTML ---------- */
const money = (n) => '$' + n.toLocaleString('en-US') + ' MXN';
const binds = {
  'count:cards': String(C.cartas.length),
  'count:guardians': String(C.guardianes.length),
  'count:commitments': String(cm.length),
};
for (const [k, p] of Object.entries(S.products)) binds['price:' + k] = money(p.priceMXN);

function walk(dir, acc = []) {
  for (const f of fs.readdirSync(dir, { withFileTypes: true })) {
    if (f.name.startsWith('.') || f.name === 'scripts') continue;
    const p = path.join(dir, f.name);
    if (f.isDirectory()) walk(p, acc); else acc.push(p);
  }
  return acc;
}
const files = walk(ROOT);
const htmlFiles = files.filter((f) => f.endsWith('.html'));
const FORBIDDEN = [
  /semana en que (se pide|lo pides|las pides)/i, /semana de tu pedido/i, /Hasta 6 idiomas/, /de 9 compromisos/,
  /que es piedra/, /Recién llegada/, /su figura ya está lista/, /\[DATO PENDIENTE/, /diez ecosistemas/i,
];
const PRIVATE = process.env.LFI_APELLIDO_PRIVADO ? process.env.LFI_APELLIDO_PRIVADO.toLowerCase() : null;
const pending = [];
for (const f of htmlFiles) {
  const rel = path.relative(ROOT, f);
  let s = fs.readFileSync(f, 'utf8');
  s = s.replace(/(<(\w+)\b[^>]*\sdata-bind="([^"]+)"[^>]*>)([^<]*)(<\/\2>)/g, (m, open, tag, key, inner, close) => {
    if (!(key in binds)) { fail(`${rel}: data-bind desconocido "${key}"`); return m; }
    return open + binds[key] + close;
  });
  s = s.replace(/\?v=(__BUILD__|\d{12})/g, '?v=' + buildId).replace(/build (__BUILD__|\d{12})/g, 'build ' + buildId);
  if (!rel.startsWith('fauna-portada-anterior')) {
    for (const re of FORBIDDEN) if (re.test(s)) fail(`${rel}: contiene texto prohibido ${re}`);
  }
  pending.push([f, s]);
}
if (PRIVATE) {
  for (const f of files) {
    if (/\.(webp|jpg|jpeg|png|pdf|mp3|woff2?)$/i.test(f)) continue;
    const s = fs.readFileSync(f, 'utf8').toLowerCase();
    if (s.includes(PRIVATE)) fail(`${path.relative(ROOT, f)}: contiene el apellido desarrollado`);
  }
}
if (errors.length) {
  console.error('✗ No se generó el sitio:\n  - ' + errors.join('\n  - '));
  process.exit(1);
}
for (const [f, s] of pending) fs.writeFileSync(f, s);
fs.writeFileSync(path.join(ROOT, 'assets-lfi/sitio-data.js'),
  '/* Generado por scripts/generar-sitio.mjs desde data/sitio.json. No editar a mano. */\nwindow.LFI_DATA=' + JSON.stringify(out) + ';\n');
console.log(`✓ Sitio generado · build ${buildId} · ${C.cartas.length} cartas · ${S.guardians.length} guardianes · precios ${Object.values(S.products).map((p) => p.priceMXN).join('/')} · ${htmlFiles.length} páginas`);
